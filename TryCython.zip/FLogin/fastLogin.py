from flask import Flask, render_template, request, redirect
from sqlalchemy import create_engine, text

app = Flask(__name__)

#engine = create_engine("mysql://root@localhost/test?charset=utf8")
#con = engine.connect()

@app.route('/', methods=['POST', 'GET'])
def index():
  #if request.method == 'POST':
  #  ID = request.form['password']
  #  command1="INSERT INTO accounts (genID) VALUES ('"+ID+"');"
  #  con.execute(text(command1))
  #  print("Inserted")
  #  return redirect('/YEY')
  return render_template('login.html')

@app.route('/timem', methods=['POST', 'GET'])
def timem():
  return render_template('TimeM.html')

@app.route('/hourd', methods=['POST', 'GET'])
def hourd():
  if request.method == 'POST':
    selected = request.json.get("selected")
    if selected == None:
      BookOrNotData = {
        'booked': [
          [0,0,-1,-1,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0],
          [0,0,0,0,0,0,0,0,0,0,0,0]
        ]
      }
      return BookOrNotData
    else:
      return selected
  else:
    return render_template('HourD.html')

app.run()

