CharDict={
  "I":1,
  "V":5,
  "X":10,
  "L":50,
  "C":100,
  "D":500,
  "M":1000
}

class Solution:
  def romanToInt(self, s: str) -> int:
    rome = s
    res=0
    Number=[]
    resRome=[]
    for i in range(len(rome)):
      Number.insert(0, CharDict[rome[i]])
    i=0
    while i<len(Number):
      currNum=Number[i]
      if i!=len(Number)-1:
        nextNum=Number[i+1]
        if (nextNum==1 or nextNum==10 or nextNum==100):
          if currNum==5*nextNum or currNum==10*nextNum:
            res+=currNum-nextNum
            i+=1
          else:
            res+=currNum
        else:
          res+=currNum
        i+=1
      else:
        res+=currNum
        break
    return res

s1 = Solution()
print(s1.romanToInt("LVIII"))
