import numpy as np
import matplotlib.pyplot as plt
import collections as colls

def plotOnes(NegOne, PosOne):
  # Plot a histogram of the random numbers
  plt.hist(NegOne, bins=30, density=True, alpha=0.5)
  plt.hist(PosOne, bins=30, density=True, alpha=0.5)
  plt.title("Histogram of Random Numbers from a Normal Distribution")
  plt.xlabel("Value")
  plt.ylabel("Frequency")
  plt.show()

NegOne = np.random.normal(loc=-1, scale=1, size=1000)
PosOne = np.random.normal(loc= 1, scale=1, size=1000)

plotOnes(NegOne, PosOne)

