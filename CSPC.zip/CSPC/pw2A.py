import matplotlib.pyplot as plt
import math
import numpy as np
arr=np.linspace(0.0, 20.0, num=100)
resx=[]
resy=[]
print(arr)
for t in arr:
    xt=50*math.sin(0.1*math.pi*t)
    resx.append(xt)
for t in arr:
    yt=50*math.sin(0.2*math.pi*t)
    resy.append(yt)
plt.plot(resx, resy)

