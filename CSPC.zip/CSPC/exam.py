import numpy as np
import scipy as sp
77.42857142857143
print(sp.no_zeros([32,111,138,28,59,77,97]))