import matplotlib.pyplot as plt
import math
import numpy as np

arr=np.linspace(0.0, 20.0, num=100)
resAx=[]
resAy=[]
print(arr)
for t in arr:
    xt=-0.5*(math.pi**2)*math.sin(0.1*math.pi*t)
    resAx.append(xt)
for t in arr:
    yt=-2*(math.pi**2)*math.sin(0.2*math.pi*t)
    resAy.append(yt)

plt.plot(resAx, resAy)

plt.show()