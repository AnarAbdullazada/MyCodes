#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>

#define MSG_SIZE 1500

typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

void readRecipe(char *filename, int msqid, int msgType) {
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) { printf("Error: Could not open recipe file.\n"); return; }
  char buffer[MSG_SIZE]; message_buf msg; msg.mtype = msgType;

  while (fgets(buffer, MSG_SIZE, fp)) {
    strncpy(msg.mtext, buffer, MSG_SIZE);
    if (msgsnd(msqid, &msg, sizeof(msg.mtext), IPC_NOWAIT) == -1) {
      perror("msgsnd");
      fclose(fp);
      return;
    }else{printf("%s", msg.mtext);}
  }

  msgctl(msqid, IPC_RMID, NULL);
  fclose(fp);
}

void write_cooking_recipe(int messageType) {
  switch (messageType) {
    case 1 :
      key_t key1 = ftok("MYINT.txt", 'I');
      int msqid1 = msgget(key1, 0666 | IPC_CREAT);
      readRecipe("./dolma.txt", msqid1, 1);
      break;
    case 2:
      key_t key2 = ftok("MYQIT.txt", 'Q');
      int msqid2 = msgget(key2, 0666 | IPC_CREAT);
      readRecipe("./dovga.txt", msqid2, 2);
      break;
    case 3:
      key_t key3 = ftok("MYTRM.txt", 'T');
      int msqid3 = msgget(key3, 0666 | IPC_CREAT);
      readRecipe("./doner.txt", msqid3, 3);
      break;
    default:
      printf("Unknown received.\n");
      break;
  }
}

int main() {
  printf("Server ready...\n");

  write_cooking_recipe(1);
  write_cooking_recipe(2);
  write_cooking_recipe(3);
  return 0;
}



