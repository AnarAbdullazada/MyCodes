#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>

#define MSG_SIZE 1500

typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

int main() {
  message_buf msg;
  int msqidCommon;
  int signal_type;

  for(int signal_type=1; signal_type<4; signal_type++){
    if (signal_type == 1) {
      key_t key1 = ftok("MYINT.txt", 'I');
      int msqid1 = msgget(key1, 0666 | IPC_CREAT);
      msqidCommon = msqid1;
      msg.mtype=1;
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    } else if (signal_type == 2) {
      key_t key2 = ftok("MYQIT.txt", 'Q');
      int msqid2 = msgget(key2, 0666 | IPC_CREAT);
      msqidCommon = msqid2;
      msg.mtype=2;
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    } else {
      key_t key3 = ftok("MYTRM.txt", 'T');
      int msqid3 = msgget(key3, 0666 | IPC_CREAT);
      msqidCommon = msqid3;
      msg.mtype=3;
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    }
  }

  if (errno != ENOMSG) {
    perror("msgrcv");
    exit(1);
  }
  msgctl(msqidCommon, IPC_RMID, NULL);
  while(1){ pause(); }
  return 0;
}
