#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>

int main() {
  pid_t server_pid;
  printf("Enter Server PID :");
  scanf("%d", server_pid);

  for (int i = 0; i < 100; i++) {
    int signal_type = rand() % 3 + 1;
    if (signal_type == 1) {
      printf("Sending SIGINT to server\n");
      kill(server_pid, SIGINT);
    } else if (signal_type == 2) {
      printf("Sending SIGQUIT to server\n");
      kill(server_pid, SIGQUIT);
    } else {
      printf("Sending SIGTERM to server\n");
      kill(server_pid, SIGTERM);
    }
    sleep(rand() % 5 + 1);
  }

  return 0;
}
