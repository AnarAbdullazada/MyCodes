#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/msg.h>

#define MSG_SIZE 256

typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

void readRecipe(char *filename, int msqid, int msgType) {
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Error: Could not open recipe file.\n");
    return;
  }
  char buffer[MSG_SIZE];
  message_buf msg;
  msg.mtype = msgType;
  while (fgets(buffer, MSG_SIZE, fp)) {
    strncpy(msg.mtext, buffer, MSG_SIZE);
    if (msgsnd(msqid, &msg, sizeof(msg.mtext), IPC_NOWAIT) == -1) {
      perror("msgsnd");
      fclose(fp);
      return;
    }
  }
  fclose(fp);
}

void handleSignal(int signal) {
  key_t key1 = ftok("MYINT.txt", 'I');
  key_t key2 = ftok("MYQIT.txt", 'Q');
  key_t key3 = ftok("MYTRM.txt", 'T');
  int msqid1 = msgget(key1, 0666 | IPC_CREAT);
  int msqid2 = msgget(key2, 0666 | IPC_CREAT);
  int msqid3 = msgget(key3, 0666 | IPC_CREAT);
  if (msqid1 == -1) {
    perror("msgget");
    return;
  }

  switch (signal) {
    case SIGINT :
      readRecipe("./Azeri/dolma.txt",   msqid1, 1);
      break;
    case SIGQUIT:
      readRecipe("./French/crepes.txt", msqid2, 2);
      break;
    case SIGTERM:
      readRecipe("./Student/doner.txt", msqid3, 3);
      break;
    default:
      printf("Unknown signal received.\n");
      break;
  }
}

int main() {
  pid_t server_pid;
  server_pid = getpid();
  printf("Server %d ready to receive signals...\n", server_pid);

  signal(SIGINT , handleSignal);
  signal(SIGQUIT, handleSignal);
  signal(SIGTERM, handleSignal);

  printf("Listening for signals...\n");
  while (1) {
    pause();
  }
  return 0;
}


