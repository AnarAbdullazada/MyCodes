#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>

#define MSG_SIZE 100000

typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

int main() {
  pid_t server_pid;
  printf("Enter Server PID :");
  scanf("%d", &server_pid);
  printf("%d", server_pid);

  message_buf msg;
  int msqidCommon;

  for (int i = 0; i < 100; i++) {
    int signal_type = rand() % 3 + 1;
    if (signal_type == 1) {
      printf("\nSending SIGINT to server\n");
      kill(server_pid, SIGINT);
    } else if (signal_type == 2) {
      printf("\nSending SIGQUIT to server\n");
      kill(server_pid, SIGQUIT);
    } else {
      printf("\nSending SIGTERM to server\n");
      kill(server_pid, SIGTERM);
    }

    sleep(1);

    key_t key1 = ftok("MYINT.txt", 'I');
    key_t key2 = ftok("MYQIT.txt", 'Q');
    key_t key3 = ftok("MYTRM.txt", 'T');
    int msqid1 = msgget(key1, 0666 | IPC_CREAT);
    int msqid2 = msgget(key2, 0666 | IPC_CREAT);
    int msqid3 = msgget(key3, 0666 | IPC_CREAT);
    if (signal_type == 1) {
      msqidCommon = msqid1;
    } else if (signal_type == 2) {
      msqidCommon = msqid2;
    } else {
      msqidCommon = msqid3;
    }
    while (msgrcv(msqidCommon, &msg, MSG_SIZE, 1, IPC_NOWAIT) != -1) {
      printf("%s", msg.mtext);
    }
    if (errno != ENOMSG) {
      perror("msgrcv");
      exit(1);
    }
  }
  msgctl(msqidCommon, IPC_RMID, NULL);

  return 0;
}

