#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

void getRecipe(char* Who){
  if(strcmp(Who, "Student")==0){
    printf("Doner:\nIngredients:\n- 500g lamb mince\n- 1 onion, grated\n- 1 tsp salt\n- 1 tsp black pepper\n- 1 tsp paprika\n- 1 tsp cumin\n- 2 tbsp tomato paste\n- 2 tbsp vegetable oil\n- 1 tbsp butter\n- 4-6 pita breads\n- 1 cup chopped lettuce\n- 1 cup chopped tomatoes\n- 1 cup chopped cucumber\n- 1 cup plain yogurt\n- 1 garlic clove, minced\n- 1 lemon, juiced\n""Instructions:\n- In a bowl, mix together the lamb mince, grated onion, salt, black pepper, paprika, cumin, and tomato paste until well combined.\n- Shape the lamb mixture into a large ball and place it on a skewer. Cook the lamb on a rotisserie or grill, turning occasionally, until cooked through and crispy on the outside.\n- Heat the vegetable oil and butter in a frying pan over medium heat. Fry the pita breads for a minute on each side until lightly golden and crispy.\n- In a small bowl, mix together the yogurt, minced garlic, and lemon juice.\n- To serve, cut the lamb into thin slices and arrange on the pita breads. Top with chopped lettuce, tomatoes, and cucumber. Drizzle with the garlic yogurt sauce.\n\nChocolate croissant:\nIngredients:\n- 1 sheet of puff pastry\n- 1/4 cup chocolate chips\n- 1 egg, beaten\nInstructions:\n- Preheat the oven to 375°F (190°C).\n- Roll out the puff pastry sheet and cut it into triangles.\n- Place a few chocolate chips on the wide end of each triangle.\n- Roll up the pastry from the wide end to the narrow end, tucking in the sides as you go.\n- Place the croissants on a baking sheet lined with parchment paper.\n- Brush the croissants with the beaten egg.\n- Bake for 15-20 minutes, or until the croissants are golden brown.\n");}
  if(strcmp(Who, "Azeri")==0){
    printf("Dolma:\nIngredients:\n- 1 lb. ground beef or lamb\n- 1 onion, finely chopped\n- 1/2 cup rice, rinsed\n- 1/2 cup chopped fresh parsley\n- 1/2 cup chopped fresh mint\n- 1/2 cup chopped fresh dill\n- 1/2 cup chopped scallions\n- 1/4 cup lemon juice\n- 1/4 cup olive oil\n- Salt and pepper, to taste\n- 1 lb. grape leaves, rinsed and drained\n- 1 lemon, sliced\n,Instructions:\n- In a large bowl, mix together the ground beef or lamb, onion, rice, parsley, mint, dill, scallions, lemon juice, olive oil, salt, and pepper.\n- Rinse the grape leaves and remove the stems.\n- Place a grape leaf on a work surface with the shiny side down and the stem end facing you.\n- Place a small spoonful of the meat mixture near the stem end of the grape leaf.\n- Fold the bottom of the leaf over the meat, then fold in the sides and roll up the leaf tightly.\n- Repeat with the remaining grape leaves and meat mixture.\n- Place the dolmas in a large pot in a single layer, seam side down.\n- Cover the dolmas with water and place the lemon slices on top.\n- Bring the water to a boil, then reduce the heat and simmer for 45-60 minutes, or until the dolmas are tender and the rice is cooked through.\n- Remove the dolmas from the pot with a slotted spoon and serve hot or cold.\n,\n,Dovga:\n,Ingredients:\n- 1 cup plain yogurt\n- 2 cups water\n- 1/2 cup rice, rinsed\n- 1 egg\n- 1/4 cup chopped fresh mint\n- 1/4 cup chopped fresh dill\n- 1 tbsp butter\n- 1 tbsp flour\n- Salt and pepper, to taste\n- 1/4 cup chopped walnuts (optional)\n,Instructions:\n- In a large pot, whisk together the yogurt, water, and rice until well combined.\n- Bring the mixture to a boil over medium-high heat, then reduce the heat and simmer for 30-40 minutes, or until the rice is cooked through.\n- In a small bowl, beat the egg until light and fluffy.\n- Gradually whisk in a ladleful of the hot yogurt mixture, then slowly pour the egg mixture into the pot, whisking constantly.\n- Add the chopped mint and dill to the pot and stir to combine.\n- In a small frying pan, melt the butter over medium heat. Add the flour and stir to make a roux.\n- Gradually whisk the roux into the pot, stirring constantly, until the dovga thickens.\n- Season with salt and pepper to taste.\n- Serve hot, garnished with chopped walnuts if desired.\n");}
  if(strcmp(Who, "French")==0){
    printf("French Crepes:\n,Ingredients:\n- 1 cup all-purpose flour\n- 2 eggs\n- 1/2 cup milk\n- 1/2 cup water\n- 2 tbsp melted butter\n- 1 tbsp sugar\n- 1/2 tsp vanilla extract\n- Pinch of salt\n,Instructions:\n- In a large bowl, whisk together the flour, eggs, milk, water, melted butter, sugar, vanilla extract, and salt until well combined.\n- Cover the bowl and refrigerate the batter for at least 30 minutes, or up to overnight.\n- Heat a non-stick frying pan over medium heat. Grease the pan lightly with butter.\n- Pour a small amount of the batter into the pan and swirl the pan to evenly coat the bottom.\n- Cook the crepe for about 2 minutes, or until the edges are golden brown and the surface is set.\n- Use a spatula to flip the crepe and cook for an additional minute on the other side.\n- Repeat with the remaining batter, greasing the pan as needed.\n- Serve the crepes hot, filled with your choice of sweet or savory fillings.\n,\n,Triple-Threat Onion Galette:\n,Ingredients:\n- For the crust:\n- 1 1/4 cups all-purpose flour\n- 1/4 tsp salt\n- 8 tbsp cold unsalted butter, cubed\n- 3-4 tbsp ice water\n- For the filling:\n- 3 tbsp unsalted butter\n- 1 large red onion, thinly sliced\n- 1 large yellow onion, thinly sliced\n- 1 large white onion, thinly sliced\n- 1/2 cup grated Gruyere cheese\n- 1/4 cup grated Parmesan cheese\n- 1/4 cup chopped fresh chives\n- Salt and pepper, to taste\n- Instructions:\n- In a large bowl, whisk together the flour and salt.\n- Add the cold butter to the bowl and use a pastry blender or your fingertips to cut the butter into the flour until the mixture resembles coarse crumbs.\n- Add the ice water, 1 tablespoon at a time, and mix until the dough comes.");}
}

void signal_handler(int signal) {
  switch(signal) {
    case SIGINT:
      printf("Received SIGINT signal, printing recipe...\n");
      getRecipe("Student");
      break;
    case SIGQUIT:
      printf("Received SIGQUIT signal, printing recipe...\n");
      getRecipe("Azeri");
      break;
    case SIGTERM:
      printf("Received SIGTERM signal, printing recipe...\n");
      getRecipe("French");
      break;
    default:
      printf("Received unknown signal: %d\n", signal);
  }
}

int main() {
  pid_t server_pid;
  server_pid = getpid();
  printf("Server %d ready to receive signals...\n", server_pid);

  signal(SIGINT, signal_handler);
  signal(SIGQUIT, signal_handler);
  signal(SIGTERM, signal_handler);

  while (1) {
    pause();
  }

  return 0;
}
