// Including required libraries
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>

// Maximum message size
#define MSG_SIZE 1500

// Struct for message buffer
typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

// Reads recipe from file and sends messages to message queue
void readRecipe(char *filename, int msqid, int msgType) {
  // Open recipe file
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) { printf("Error: Could not open recipe file.\n"); return; }

  // Initialize buffer and message
  char buffer[MSG_SIZE];
  message_buf msg;
  msg.mtype = msgType;

  // Read recipe file line by line and send messages to message queue
  while (fgets(buffer, MSG_SIZE, fp)) {
    // Copy line to message buffer
    strncpy(msg.mtext, buffer, MSG_SIZE);

    // Send message to message queue
    if (msgsnd(msqid, &msg, sizeof(msg.mtext), IPC_NOWAIT) == -1) {
      perror("msgsnd");
      fclose(fp);
      return;
    } else {
      // Print message if it is sent successfully
      printf("%s", msg.mtext);
    }
  }

  // Remove message queue and close recipe file
  msgctl(msqid, IPC_RMID, NULL);
  fclose(fp);
}

// Writes cooking recipe to message queue
void write_cooking_recipe(int messageType) {
  switch (messageType) {
    case 1:
      key_t key1 = ftok("MYINT.txt", 'I');
      // Create message queue with the generated key
      int msqid1 = msgget(key1, 0666 | IPC_CREAT);
      // Read recipe and send messages to message queue
      readRecipe("./Azeri/recipe1.txt", msqid1, 1);
      // Remove message queue
      if (msgctl(msqid1, IPC_RMID, NULL) == -1) { perror("msgctl"); exit(1); }
      break;
    case 2:
      key_t key2 = ftok("MYQIT.txt", 'Q');
      // Create message queue with the generated key
      int msqid2 = msgget(key2, 0666 | IPC_CREAT);
      // Read recipe and send messages to message queue
      readRecipe("./French/recipe1.txt", msqid2, 2);
      // Remove message queue
      if (msgctl(msqid2, IPC_RMID, NULL) == -1) { perror("msgctl"); exit(1); }
      break;
    case 3:
      key_t key3 = ftok("MYTRM.txt", 'T');
      // Create message queue with the generated key
      int msqid3 = msgget(key3, 0666 | IPC_CREAT);
      // Read recipe and send messages to message queue
      readRecipe("./students/recipe1.txt", msqid3, 3);
      // Remove message queue
      if (msgctl(msqid3, IPC_RMID, NULL) == -1) { perror("msgctl"); exit(1); }
      break;
    default:
      printf("Unknown received.\n");
      break;
  }
}

// Main function
int main() {
  // Print message when server is ready
  printf("Server ready...\n");

  // Write cooking recipes to message queues
  write_cooking_recipe(1);
  write_cooking_recipe(2);
  write_cooking_recipe(3);

  return 0;
}
