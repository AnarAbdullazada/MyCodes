// Include required header files
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>

// Define maximum message size
#define MSG_SIZE 1500

// Define a structure for the message buffer
typedef struct msgbuf {
  long mtype;
  char mtext[MSG_SIZE];
} message_buf;

// Define the main function
int main() {
  // Initialize variables
  message_buf msg;
  int msqidCommon;
  int signal_type;

  // Loop through the signal types
  for(int signal_type=1; signal_type<4; signal_type++){
    // Handle signal type 1
    if (signal_type == 1) {
      // Generate a key for the message queue
      key_t key1 = ftok("MYINT.txt", 'I');
      int msqid1 = msgget(key1, 0666 | IPC_CREAT);
      msqidCommon = msqid1;
      // Set the message type
      msg.mtype=1;
      // Receive the message from the message queue
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    } else if (signal_type == 2) { // Handle signal type 2
      // Generate a key for the message queue
      key_t key2 = ftok("MYQIT.txt", 'Q');
      int msqid2 = msgget(key2, 0666 | IPC_CREAT);
      msqidCommon = msqid2;
      // Set the message type
      msg.mtype=2;
      // Receive the message from the message queue
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    } else { // Handle signal type 3
      // Generate a key for the message queue
      key_t key3 = ftok("MYTRM.txt", 'T');
      int msqid3 = msgget(key3, 0666 | IPC_CREAT);
      msqidCommon = msqid3;
      // Set the message type
      msg.mtype=3;
      // Receive the message from the message queue
      msgrcv(msqidCommon, &msg, MSG_SIZE, signal_type, 0);
      printf("%s\n", msg.mtext);
    }
  }

  // Check for errors during message queue receive operation
  if (errno != ENOMSG) {
    perror("msgrcv");
    exit(1);
  }

  // Remove the message queue
  msgctl(msqidCommon, IPC_RMID, NULL);
  // Loop indefinitely
  while(1){ pause(); }
  // Return 0 to indicate successful program execution
  return 0;
}
