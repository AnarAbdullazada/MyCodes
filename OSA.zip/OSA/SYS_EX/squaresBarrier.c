#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 5

pthread_barrier_t barrier;
int nums[] = {1, 2, 3, 4, 5};
int *results[NUM_THREADS];

void *square(void *arg) {
  int *num = (int *)arg;
  int *result = malloc(sizeof(int));
  printf("%d Before Sleep\n", *num);
  sleep(*num);
  printf("%d After Sleep\n" , *num);
  pthread_barrier_wait(&barrier);
  printf("Barrier is Relieved.\n");
  *result = (*num) * (*num);
  return result;
}

int sum(int length, int **array) {
  int i, total = 0;
  for (i = 0; i < length; i++) {
    total += *array[i];
    printf("%d\n", *array[i]);
  }
  return total;
}

int main() {
  pthread_t threads[NUM_THREADS];
  int i, ret, total;

  pthread_barrier_init(&barrier, NULL, NUM_THREADS-1); 

  for (i = 0; i < NUM_THREADS; i++) {
    ret = pthread_create(&threads[i], NULL, square, (void *)&nums[i]);
    if (ret != 0) {
      fprintf(stderr, "Error: pthread_create failed with code %d.\n", ret);
      exit(EXIT_FAILURE);
    }
  }

  // Wait for threads to complete and collect results
  for (i = 0; i < NUM_THREADS; i++) {
    ret = pthread_join(threads[i], (void **)&results[i]);
    if (ret != 0) {
      fprintf(stderr, "Error: pthread_join failed with code %d.\n", ret);
      exit(EXIT_FAILURE);
    }
  }

  // Calculate total sum of squares
  total = sum(NUM_THREADS, (int **)results);
  printf("The sum of squares is %d\n", total);

  // Free memory
  for (i = 0; i < NUM_THREADS; i++) { free(results[i]); }
  pthread_barrier_destroy(&barrier);

  return 0;
}
