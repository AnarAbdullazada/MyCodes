#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY_FILE "bip.txt"
#define SHM_KEY_PROJ 'A'
#define SHM_SIZE 4096

void read_data(int shmid);
void write_data(int shmid, const char* data);
int create_shared_memory(size_t size);
void dispose_shared_memory(int shmid);
int get_shared_memory_access(key_t key);

void son();
void father(int shmid);

int main() {
  pid_t pid = fork();
  if (pid == 0) { son(); }
  else {
    int shmid = create_shared_memory(4096);
    father(shmid); wait(NULL);
    dispose_shared_memory(shmid);
  }
  return 0;
}
int create_shared_memory(size_t size) {
  key_t key = ftok(SHM_KEY_FILE, SHM_KEY_PROJ);
  int shmid = shmget(key, size, IPC_CREAT | 0666);
  if (shmid == -1) { perror("shmget"); exit(EXIT_FAILURE); }
  return shmid;
}
void dispose_shared_memory(int shmid) {
  if (shmctl(shmid, IPC_RMID, NULL) == -1) {
    perror("shmctl");
    exit(EXIT_FAILURE);
  }
}

void son() {
  sleep(1);
  key_t key = ftok(SHM_KEY_FILE, SHM_KEY_PROJ);
  int shmid = get_shared_memory_access(key);
  read_data(shmid);
}
int get_shared_memory_access(key_t key) {
  // Create the shared memory segment, or get the ID of an existing one
  int shmid = shmget(key, SHM_SIZE, 0666);
  if (shmid == -1) { perror("shmget"); exit(1); }
  
  // Attach to the shared memory segment
  char *data = (char *) shmat(shmid, NULL, 0);
  if (data == (char *) -1) { perror("shmat"); exit(1); }
  
  return shmid;
}
void read_data(int shmid) {
  char* data = (char*)shmat(shmid, NULL, 0);
  printf("Received data: %s\n", data);
  shmdt(data);
}

void father(int shmid) {
  char* text = "This is a sentence from my favorite song.";
  write_data(shmid, text);
}
void write_data(int shmid, const char* data) {
  char* dest = (char*)shmat(shmid, NULL, 0);
  strncpy(dest, data, SHM_SIZE);
  shmdt(dest);
}
