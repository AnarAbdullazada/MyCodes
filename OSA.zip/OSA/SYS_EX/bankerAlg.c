#include <stdio.h>
#include <stdlib.h>

int P, R;

int *available;
int **max;
int **allocation;
int **need;
int *safeSeq;
int *finish;

void calculateNeed() {
  for (int i = 0; i < P; i++) {
    for (int j = 0; j < R; j++) {
      need[i][j] = max[i][j] - allocation[i][j];
    }
  }
}

int isSafe() {
  for (int i = 0; i < R; i++) {
    int work = available[i];
    for (int j = 0; j < P; j++) {
      if (finish[j] == 0 && need[j][i] <= work) {
        work += allocation[j][i];
        finish[j] = 1;
        safeSeq[i] = j;
      }
    }
    if (safeSeq[i] == -1) {
      return 0;
    }
  }
  return 1;
}

void banker() {
  int n = P;
  for (int i = 0; i < n; i++) {
    finish[i] = 0;
    safeSeq[i] = -1;
  }

  calculateNeed();

  if (isSafe()) {
    printf("Safe sequence: ");
    for (int i = 0; i < P; i++) {
      printf("%d ", safeSeq[i]);
    }
    printf("\n");
  } else {
    printf("System is in unsafe state\n");
  }
}

int main() {
  // Read number of processes and resources
  printf("Enter number of processes: ");
  scanf("%d", &P);
  printf("Enter number of resources: ");
  scanf("%d", &R);

  // Allocate memory for arrays
  available = (int*) malloc(R * sizeof(int));
  max = (int**) malloc(P * sizeof(int*));
  allocation = (int**) malloc(P * sizeof(int*));
  need = (int**) malloc(P * sizeof(int*));
  safeSeq = (int*) malloc(P * sizeof(int));
  finish = (int*) malloc(P * sizeof(int));

  for (int i = 0; i < P; i++) {
    max[i] = (int*) malloc(R * sizeof(int));
    allocation[i] = (int*) malloc(R * sizeof(int));
    need[i] = (int*) malloc(R * sizeof(int));
  }

  // Read available resources
  printf("Enter number of available resources for each type:\n");
  for (int i = 0; i < R; i++) {
    printf("Resource type %d: ", i);
    scanf("%d", &available[i]);
  }

  // Read maximum demand of each process
  printf("Enter maximum demand of each process:\n");
  for (int i = 0; i < P; i++) {
    printf("Process %d: ", i);
    for (int j = 0; j < R; j++) {
      scanf("%d", &max[i][j]);
    }
  }

  // Read allocation matrix
  printf("Enter current allocation matrix:\n");
  for (int i = 0; i < P; i++) {
    printf("Process %d: ", i);
    for (int j = 0; j < R; j++) {
      scanf("%d", &allocation[i][j]);
    }
  }

  banker();

  // Free memory
  free(available);
  for (int i = 0; i < P; i++) {
    free(max[i]);
    free(allocation[i]);
    free(need[i]);
  }
  free(max);
  free(allocation);
  free(need);
  free(safeSeq);
  free(finish);

  return 0;
}
