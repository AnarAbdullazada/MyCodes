#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>


void father() {
  printf("I am the father process\n");
}

void son() {
  printf("I am the son process\n");
}

int main() {
  pid_t pid = fork();
  if (pid == -1) {
    printf("Failed to fork process\n");
  } else if (pid == 0) {
    son();
  } else {
    father();
  }
  return 0;
}
