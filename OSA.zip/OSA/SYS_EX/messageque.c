#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MSG_TYPE 1
void son();
void father(int msgid);
int create_message_queue();
int get_message_queue_access();
void write_data(int msgid, char val[100]);
void read_data(int msgid);
void dispose_message_queue(int msgid);

int main() {
  pid_t pid = fork();

  if (pid == -1) {
    perror("fork");
    exit(1);
  } else if (pid == 0) {
    son();
    exit(0);
  } else {
    int msgid = create_message_queue();
    father(msgid);
    wait(NULL);
    dispose_message_queue(msgid);
  }
  return 0;
}

void son() {
  sleep(10);
  int msgid = get_message_queue_access();
  read_data(msgid);
}

void father(int msgid) {
  char val[100];
  printf("Enter name: ");
  scanf("%s", &val);
  write_data(msgid, val);
}

int create_message_queue() {
  key_t key = ftok("bap.txt", 'Y');
  int msgid = msgget(key, IPC_CREAT | 0666);
  if (msgid == -1) {
    perror("msgget");
    exit(1);
  }
  return msgid;
}

int get_message_queue_access() {
  key_t key = ftok("bap.txt", 'Y');
  int msgid = msgget(key, 0666);
  if (msgid == -1) {
    perror("msgget");
    exit(1);
  }

  return msgid;
}

void write_data(int msgid, char val[100]) {
  struct msgbuf {
    long mtype;
    int data;
  } msg;

  msg.mtype = MSG_TYPE;
  msg.data = val;

  if (msgsnd(msgid, &msg, sizeof(msg.data), IPC_NOWAIT) == -1) {
    perror("msgsnd");
    exit(1);
  }
}

void read_data(int msgid) {
  struct msgbuf {
    long mtype;
    int data;
  } msg;

  if (msgrcv(msgid, &msg, sizeof(msg.data), MSG_TYPE, IPC_NOWAIT) == -1) {
    perror("msgrcv");
    exit(1);
  }

  printf("Received data: %s\n", msg.data);
}

void dispose_message_queue(int msgid) {
  if (msgctl(msgid, IPC_RMID, NULL) == -1) {
    perror("msgctl");
    exit(1);
  }
}
