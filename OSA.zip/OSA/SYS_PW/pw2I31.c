#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#define CANARY_SIZE sizeof(unsigned long)
#define CANARY_VALUE ((unsigned long)0xdeadbeef)

void *my_malloc(size_t size) {
  void *ptr = malloc(size + 2 * CANARY_SIZE);
  if (ptr == NULL) {
    return NULL;
  }
  memset(ptr, 0, size + 2 * CANARY_SIZE);
  *(unsigned long *)ptr = CANARY_VALUE;
  *(unsigned long *)((char *)ptr + CANARY_SIZE + size) = CANARY_VALUE;
  return (void *)((char *)ptr + CANARY_SIZE);
}

void my_free(void *ptr) {
  char *start = (char *)ptr - CANARY_SIZE;
  if (memcmp(start, (void *)&CANARY_VALUE, CANARY_SIZE) != 0 || memcmp(start + CANARY_SIZE + sizeof(size_t), (void *)&CANARY_VALUE, CANARY_SIZE) != 0){
    abort();
  }
  free(start);
}

int main() {
  void *ptr = my_malloc(10);
  my_free(ptr);
  return 0;
}
