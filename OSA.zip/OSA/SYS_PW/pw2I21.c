#include <stdio.h>
#define RELATIVE_ADDRESS(s, c) ((long)&s.c  - (long)&s)
//((s *)0)->c

struct toto {
  char c;
  char *pc;
  int i;
  char d;
};
struct toto1 {
  char c ;
  char* pc; 
  int i ; 
}
struct toto2 {
  char c ;
  int i ; 
  char* pc ;
}
struct toto3 {
  char c ;
  char* pc 
  int i ; 
} *
struct toto4 {
  char c ;
  int i ; 
  char* pc ; 
} __attribute__((packed))

int main() {
  struct toto v;

  printf("Address of v.c: %ld\n",  RELATIVE_ADDRESS(v, c ));
  printf("Address of v.pc: %ld\n", RELATIVE_ADDRESS(v, pc));
  printf("Address of v.i: %ld\n",  RELATIVE_ADDRESS(v, i ));
  printf("Address of v.d: %ld\n",  RELATIVE_ADDRESS(v, d ));

  return 0;
}

//Address of v.c:  0
//Address of v.pc: 8
//Address of v.i:  16
//Address of v.d:  20
