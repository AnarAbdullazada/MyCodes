#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

#define BUF_SIZE 1024

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  
  int fd = open(argv[1], O_RDONLY);
  if (fd == -1) {
    perror("open");
    exit(EXIT_FAILURE);
  }
  
  struct stat st;
  if (fstat(fd, &st) == -1) {
    perror("fstat");
    exit(EXIT_FAILURE);
  }
  
  char *addr = mmap(NULL, st.st_size, PROT_READ, MAP_SHARED, fd, 0);
  if (addr == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);
  }
  
  char buf[BUF_SIZE];
  size_t len = 0;
  
  // print first line
  while (addr[len] != '\n') {
    buf[len % BUF_SIZE] = addr[len];
    len++;
  }
  printf("First line: %.*s\n", (int)len, buf);
  
  // print last line
  size_t end = st.st_size - 1;
  while (addr[end] != '\n') {
    end--;
  }
  len = 0;
  for (size_t i = end + 1; i < st.st_size; i++) {
    buf[len % BUF_SIZE] = addr[i];
    len++;
  }
  printf("Last line: %.*s\n", (int)len, buf);
  
  if (munmap(addr, st.st_size) == -1) {
    perror("munmap");
    exit(EXIT_FAILURE);
  }
  
  if (close(fd) == -1) {
    perror("close");
    exit(EXIT_FAILURE);
  }
  
  return 0;
}
