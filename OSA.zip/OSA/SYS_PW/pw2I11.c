#include <stdio.h>

int main() {
  printf("Size of int: %ld bytes\n", sizeof(int));
  printf("Size of char: %ld bytes\n", sizeof(char));
  printf("Size of char*: %ld bytes\n", sizeof(char*));
  printf("Size of struct { char c ; char* pc ; int i ; }: %ld bytes\n", sizeof(struct { char c ; char* pc ; int i ; }));
  printf("Size of struct { char c ; int i ; char* pc ; }: %ld bytes\n", sizeof(struct { char c ; int i ; char* pc ; }));
  printf("Size of struct { char c ; char* pc ; int i ; } *: %ld bytes\n", sizeof(struct { char c ; char* pc ; int i ; } *));
  printf("Size of struct { char c ; int i ; char* pc ; } __attribute__((packed)): %ld bytes\n", sizeof(struct { char c ; int i ; char* pc ; } __attribute__((packed))));
}


//Size of int                                                           : 4  bytes
//Size of char                                                          : 1  bytes
//Size of char*                                                         : 8  bytes
//On 64 byte system pointers take 8*8 bits. So any pointer would be 8 bytes.

//Size of struct { char c ; char* pc ; int i ; }                        : 24 bytes
//It is 24 bytes because compiler adds additional bytes to allign members of struct.

//Size of struct { char c ; int i ; char* pc ; }                        : 16 bytes
//IDK

//Size of struct { char c ; char* pc ; int i ; } *                      : 8  bytes
//On 64 byte system pointers take 8*8 bits. So any pointer including struct* would be 8 bytes.

//Size of struct { char c ; int i ; char* pc ; } __attribute__((packed)): 13 bytes
//Packed means padding is removed from struct. 1+8+4=13