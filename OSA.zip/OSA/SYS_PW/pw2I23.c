#include <stdio.h>
#define RELATIVE_ADDRESS(s,c) ((char *)&s.c - (char *)&s)

struct toto1 {
  char c ;
  char* pc;
  int i ; 
};

struct toto2 {
  char c ;
  int i ; 
  char* pc ;
};

struct toto3{
  char c ;
  char* pc; 
  int i ; 
} ;

struct toto4 {
  char c ;
  int i ; 
  char* pc ; 
} __attribute__((packed));

int main() {
  struct toto1 t1;
  printf("Relative address of t1.c: %ld\n", RELATIVE_ADDRESS(t1, c));
  printf("Relative address of t1.pc: %ld\n", RELATIVE_ADDRESS(t1, pc));
  printf("Relative address of t1.i: %ld\n", RELATIVE_ADDRESS(t1, i));
      
  struct toto2 t2;
  printf("Relative address of t2.c: %ld\n", RELATIVE_ADDRESS(t2, c));
  printf("Relative address of t2.i: %ld\n", RELATIVE_ADDRESS(t2, i));
  printf("Relative address of t2.pc: %ld\n", RELATIVE_ADDRESS(t2, pc));
      
  struct toto3 *t3;
  printf("Relative address of t3->c: %ld\n", RELATIVE_ADDRESS((*t3), c));
  printf("Relative address of t3->pc: %ld\n", RELATIVE_ADDRESS((*t3), pc));
  printf("Relative address of t3->i: %ld\n", RELATIVE_ADDRESS((*t3), i));
      
  struct toto4 t4;
  printf("Relative address of t4.c: %ld\n", RELATIVE_ADDRESS(t4, c));
  printf("Relative address of t4.i: %ld\n", RELATIVE_ADDRESS(t4, i));
  printf("Relative address of t4.pc: %ld\n", RELATIVE_ADDRESS(t4, pc));
  return 0;
}

//Relative address of t1.c: 0
//Relative address of t1.pc: 8
//Relative address of t1.i: 16
//Relative address of t2.c: 0
//Relative address of t2.i: 4
//Relative address of t2.pc: 8
//Relative address of t3->c: 0
//Relative address of t3->pc: 8
//Relative address of t3->i: 16
//Relative address of t4.c: 0
//Relative address of t4.i: 1
//Relative address of t4.pc: 5