import random as rn
stundentNum = 40

stundent={
  'StdId': None,
  'FavoriteOrd': []
}

dest={
  'Id': None,
  'maxNumber' : None,
  'curNumber' : 0
}
dest['MaxNumber'] =rn.randint(0, 10)

dest['curNumber']+=1
print(dests['maxNumber'])
