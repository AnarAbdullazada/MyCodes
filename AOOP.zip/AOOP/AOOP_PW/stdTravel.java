import java.util.Random;

class Student{
  int StdID = 0;
  int[] FavoriteOrd = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
class Destination{
  int Id = 0;
  int maxNumber = 0;
  int curNumber = 0;
  Destination(int Id, int maxNumber){
    this.Id=Id;
    this.maxNumber=maxNumber;
  }
}

class stdTravel
{
	public static void main(String args[])
	{
    Random rand = new Random();
    Destination[] distArr= {0,0,0,0,0,0,0,0,0,0}; int distArrCounter=0;
    for(int i=0; i<10; i++){
      Destination curDest = new Destination(0, rand.nextInt(1, 5));
      distArr[distArrCounter] = curDest; distArrCounter++;
      System.out.println(curDest.maxNumber);
    }
	}
}
