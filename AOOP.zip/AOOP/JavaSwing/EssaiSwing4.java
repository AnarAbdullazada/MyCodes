import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EssaiSwing4 extends JFrame {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Menu Test");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setMinimumSize(new Dimension(250, 200));

    TestMenuSwing menu = new TestMenuSwing();
    frame.setJMenuBar(menu);

    frame.pack();
    frame.setVisible(true);
  }
}

//In this modified code, the actionPerformed() method of the afficherMenuListener
//checks if the selected command is "Quit", and if it is, it calls System.exit(0)
//to terminate the application. For all other commands, it prints a message
//to the console.