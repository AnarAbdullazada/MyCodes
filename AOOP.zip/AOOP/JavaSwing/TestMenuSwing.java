import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TestMenuSwing extends JMenuBar {
  public TestMenuSwing() {
    ActionListener afficherMenuListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        if (cmd.equals("Quit")) {
          System.exit(0); ///Terminate when Quit is selected.
        } else {
          System.out.println("Used menu element [" + cmd + "]");
        }
      }
    };

    JMenu fichierMenu = new JMenu("File");

    JMenuItem item = new JMenuItem("New", 'n');
    item.addActionListener(afficherMenuListener);
    fichierMenu.add(item);

    item = new JMenuItem("Open", 'o');
    item.addActionListener(afficherMenuListener);
    fichierMenu.add(item);

    item = new JMenuItem("Save", 'a');
    item.addActionListener(afficherMenuListener);
    fichierMenu.add(item);

    fichierMenu.addSeparator();

    item = new JMenuItem("Quit");
    item.addActionListener(afficherMenuListener);
    fichierMenu.add(item);

    this.add(fichierMenu);
  }
}

//To alter the source code so that the application terminates
//Add an action to the "Quit" menu item that, when the "Quit" option is chosen, 
//calls the System.exit() method to end the application.
