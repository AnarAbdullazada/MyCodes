package connecteComplet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Serveur {
 
    public static void main(String[] args) {
    	ServerSocket socketserver  ;
        Socket socket1 ;
        BufferedReader in;
        PrintWriter out;
        
        try {
            socketserver = new ServerSocket(2009);
            System.out.println("Le serveur est � l'�coute du port "+socketserver.getLocalPort());
            socket1 = socketserver.accept(); 
            System.out.println("Un client s'est connect�");
            out = new PrintWriter(socket1.getOutputStream());
            out.println("Vous �tes connect� !");
            out.flush();
            socket1.close();
            socketserver.close();
        }catch (IOException e) {
              e.printStackTrace();
        }
    }
}