import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class elsh {
    public static void main(String[] args) {

	InetAddress localAddress;
	InetAddress serverAddress;
	
	try {
		localAddress = InetAddress.getLocalHost();
		System.out.println(localAddress);
	}catch(UnknownHostException e){e.printStackTrace();}
	
    }
}