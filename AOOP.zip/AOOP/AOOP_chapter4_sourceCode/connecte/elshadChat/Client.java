import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.net.*;
import java.io.*;
import java.util.*;

public class Client {
	public static void main(String[] args) {
		Socket socket2;
		try {
	        Scanner scanner = new Scanner(System.in);

			String message1 =  scanner.nextLine();
			socket2 = new Socket("192.168.53.229", 2009);
			PrintWriter out = new PrintWriter(socket2.getOutputStream(), true);
			out.println(message1);
			InputStream input = socket2.getInputStream();
			byte[] buffer = new byte[1024];
			int bytesRead = input.read(buffer);
			String message = new String(buffer, 0, bytesRead);
			System.out.println("Received message: " + message);
			socket2.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}