import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Serveur {
    private List<Socket> clients = new ArrayList<>();

    public void start() {
        try {
            ServerSocket serverSocket = new ServerSocket(2009);
            System.out.println("Server started.");

            while (true) {
                // Wait for a client to connect
                Socket clientSocket = serverSocket.accept();
                clients.add(clientSocket);
                System.out.println("Client connected.");

                // Create a new thread to handle the client
                Thread t = new Thread(new ClientHandler(clientSocket));
                t.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                InputStream input = clientSocket.getInputStream();
                byte[] buffer = new byte[1024];

                while (true) {
                    int bytesRead = input.read(buffer);
                    if (bytesRead == -1) {
                        break;
                    }

                    // Broadcast the message to all connected clients
                    String message = new String(buffer, 0, bytesRead);
                    for (Socket socket : clients) {
                        if (socket != clientSocket) {
                            OutputStream output = socket.getOutputStream();
                            output.write(message.getBytes());
                        }
                    }
                }

                // Remove the client socket from the list of connected sockets
                clients.remove(clientSocket);
                clientSocket.close();
                System.out.println("Client disconnected.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Serveur server = new Serveur();
        server.start();
    }
}
