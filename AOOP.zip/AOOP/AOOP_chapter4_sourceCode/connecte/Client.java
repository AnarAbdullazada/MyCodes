import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket2 = new Socket("192.168.1.65", 2009);
            OutputStream output = socket2.getOutputStream();
            new Thread(() -> {
                try {
                    InputStream input = socket2.getInputStream();
                    byte[] buffer = new byte[1024];
                    while (true) {
                        int bytesRead = input.read(buffer);
                        String message = new String(buffer, 0, bytesRead);
                        System.out.println("Received message: " + message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();

            Scanner in = new Scanner(System.in);
            while (true) {
                String inputmessage = in.nextLine();
                output.write(inputmessage.getBytes());
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
