package connecteSerialize;


import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {    
		
		Document d = new Document ("this is an example");

        Socket socket2;
        BufferedReader in;
        PrintWriter out;
        try {
            socket2 = new Socket(InetAddress.getLocalHost(),2009);   
            System.out.println("Demande de connexion");
            
            OutputStream os = socket2.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(os);
			System.out.println("Sending the document to the server");
			oos.writeObject(d);
			
			InputStream is = socket2.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(is);
            
            d = (Document) ois.readObject();
            System.out.println ("document received ---/// "+d.toString());
			
		    System.out.println("Closing socket and terminating Client");
            socket2.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
