package connecteSerialize;


import java.io.*;
import java.net.*;
import java.util.*;

public class Serveur {
 
    public static void main(String[] args) {
    	ServerSocket socketserver  ;
        Socket socket1 ;
        //BufferedReader in;
        //PrintWriter out;
        
        try {
            socketserver = new ServerSocket(2009);
            
            System.out.println("Le serveur est � l'�coute du port "+socketserver.getLocalPort());
            
            socket1 = socketserver.accept(); 
            System.out.println("Un client s'est connect�");
            
            InputStream is = socket1.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(is);
            
            Document d = (Document)ois.readObject();
            System.out.println ("document received ... crypting");
            
            d.setContenu (d.getContenu() + "  is crypted  ");
            
            OutputStream os = socket1.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(os);
			System.out.println("Sending crypted document to the client");
			oos.writeObject(d);
			 
			 System.out.println("closing connections");
            
            //out = new PrintWriter(socket1.getOutputStream());
            //out.println("Vous �tes connect� !");
            //out.flush();
            socket1.close();
            socketserver.close();
        }catch (Exception e) {
              e.printStackTrace();
        }
    }
}
