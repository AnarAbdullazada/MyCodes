package connecteSerialize;

import java.io.Serializable;

public class Document implements Serializable

{

private String content ;

public Document ()
	{
		this.content = " Content not defined ";
	}

public Document ( String newContent ) 
	{
		this.content = newContent ;
	}

public String getContenu ()
	{
		return this.content ;
	}
	
public void setContenu ( String newContent ) 
	{
		this.content = newContent ;
	}
	
public String toString () 
	{
		return this.content ;
	}
	
	
}
