public class MainABC {
  public static void main(String[] args) {
    C thC = new C(); B thB = new B(thC); A thA = new A(thB); 
    thA.start(); thB.start(); thC.start();
  }
}
