public class C extends Thread{
  public void Sleeper(){
    try{ sleep(1000); }
    catch(InterruptedException e){}
  }
  public void run(){
    this.Sleeper();
    System.out.println("I am C");
  }
}