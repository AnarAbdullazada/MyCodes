public class A extends Thread{
  Thread thB = null;
  public A(Thread thB){
    this.thB = thB;
  }
  public void Sleeper(){
    try{ sleep(1000); }
    catch(InterruptedException e){}
  }
  public void run(){
    this.Sleeper();
    try{thB.join();}
    catch(InterruptedException e){}
    System.out.println("I am A");
  }
}
