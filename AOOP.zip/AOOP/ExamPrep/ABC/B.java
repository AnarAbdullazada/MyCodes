public class B extends Thread{
  Thread thC = null;
  public B(Thread thC){
    this.thC = thC;
  }
  public void Sleeper(){
    try{ sleep(1000); }
    catch(InterruptedException e){}
  }
  public void run(){
    this.Sleeper();
    try{thC.join();}
    catch(InterruptedException e){}
    System.out.println("I am B");
  }
}