public class TestThread3 extends Thread
{
	private String s ;

	public TestThread3 (String s)
	{ 
		this.s=s ; 
	}
	

	public void run() 
	{
		for  (int  i = 1 ;   i <= 5;   i ++) 
		{
				System.out.print(s + "  ");
				double n = Math.random()*5;
				int t = (int) n;
				try {  sleep (t*1000); } 
				catch (InterruptedException e)  {  }
        }
        System.out.println();
        
        try {this.wait(25000);
			//this.notifyAll();
			}
			catch (Exception e){}
        
      
				
        System.out.println (this.s +" it's over");
	}
}


