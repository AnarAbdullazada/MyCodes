public class TestThread2 implements Runnable
{
	private String s;
	
	public TestThread2 (String s)
	{
		this.s = s;
	}
	
	public void run()
	{
		while (true)
		{
				System.out.println(s);
				try { Thread.sleep (100); } 
				catch (InterruptedException e)  {  }
        }
	}
}



