public class CountingThreads {
  public static void main(String[] args) {
    Thread TA = new Thread(new CountUp());
    Thread TB = new Thread(new CountDown());
    TA.start();
    TB.start();
  }

  private static class CountUp implements Runnable {
    @Override
    public void run() {
      for (int i = 1; i <= 1000; i++) {
        System.out.println("CountUp: " + i);
      }
    }
  }

  private static class CountDown implements Runnable {
    @Override
    public void run() {
      for (int i = 1000; i >= 1; i--) {
        System.out.println("CountDown: " + i);
      }
    }
  }
}
