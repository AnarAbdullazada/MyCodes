import java.io.*;
import java.util.*;

class myJava
{
	public static class GFG extends Thread {
		// initiated run method for Thread
		public int index;
		public int timer;
		GFG(int index, int timer){
			this.index=index;
			this.timer=timer;
		}
		public void run() // run() is special keyword from Thread.
		{
			System.out.println("Thread"+this.index+" Started");
			try{Thread.sleep(this.timer);}catch(InterruptedException e){System.out.println(e);} 
			System.out.println("Thread"+this.index+" Finished");
		}
	}
	public static void main(String[] args)
	{
		GFG g1 = new GFG(1, 500);
		GFG g2 = new GFG(2, 100);
		g1.start();
		g2.start();
	}
}
