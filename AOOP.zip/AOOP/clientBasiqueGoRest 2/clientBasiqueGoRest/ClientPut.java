import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ClientPut {
	public static void main(String[] args) {
	  try {
		//change le nom de l'utilisateur 3122 à abcdefghijklm
		URL url = new URL("https://gorest.co.in/public/v2/users/3122");
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("PUT");
		//Headers de la requête HPPT ... en particulier le type de donnée que je vais envoyer et le token d'authorization de GoRest
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestProperty("Authorization", "Bearer 7a1dcbf8054398dd89ec291516d49821b03a65572e20d2484e1bca50b46d4049"); //<-- ICI VOTRE TOKEN

		String input = "{\"name\": \"abcdefghijklm\"}"; // en syntaxe Jason (car c'est ce qu'on a dit dans la ligne 20

		OutputStream os = conn.getOutputStream();
		os.write(input.getBytes());
		os.flush();

		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
		String output;
		System.out.println("Output from Server .... ");
		while ((output = br.readLine()) != null) {
			System.out.println(output);
		}

		conn.disconnect();
	  } catch (MalformedURLException e) {
			e.printStackTrace();
	  } catch (IOException e) {
			e.printStackTrace();
	 }
	}
}
