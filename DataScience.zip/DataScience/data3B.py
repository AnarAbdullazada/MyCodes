import numpy as np
import matplotlib.pyplot as plt

f=open("data.txt", "r")
file=f.read()
list=[]
res=[]
list=file.split("\n")
for elem in list:
    dirt=elem.split("|")
    for e in dirt:
        if e=="":
            dirt.remove(e)
        else:
            dirt[dirt.index(e)]=e.replace(" ", "")
    res.append(dirt)

print(res)
double=[]
for i in res:
    for k in i:
        if i[0]!=k:
            loop=i.index(k)
            double.append([float(i[0]), float(k)])
double=np.array(double)
double=np.transpose(double)

eachfive=np.array_split(double[1], 5)

print(eachfive)
figure, axis = plt.subplots(1, 2)
axis[0].hist(eachfive, orientation="horizontal")
axis[1].boxplot(eachfive)
plt.show()