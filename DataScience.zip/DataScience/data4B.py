import numpy as np
import matplotlib.pyplot as plt
import math

f=open("data.txt", "r")
file=f.read()
list=[]
res=[]
list=file.split("\n")
for elem in list:
    dirt=elem.split("|")
    for e in dirt:
        if e=="":
            dirt.remove(e)
        else:
            dirt[dirt.index(e)]=e.replace(" ", "")
    res.append(dirt)

double=[]
for i in res:
    for k in i:
        if i[0]!=k:
            loop=i.index(k)
            double.append([float(round(int(i[0])+loop*(1/12), 2)), float(k)])
double=np.array(double)
double=np.transpose(double)
print(double)

uniques, counts = np.unique(double[1], return_counts=True)
mode=uniques[np.where(counts == max(counts))]
print("mode", mode)

q25 = np.percentile(double[1], [25])
print("first quartile: ", q25[0])
q75 = np.percentile(double[1], [75])
print("third quartile: ", q75[0])

highmark=q75+(q75-q25)*1.5
lowmark=q25-(q75-q25)*1.5

highExtDate=double[0][np.where(double[1]>highmark)]
highExt=double[1][np.where(double[1]>highmark)]
lowExtDate=double[0][np.where(double[1]<lowmark)]
lowExt=double[1][np.where(double[1]<lowmark)]
print(highExtDate, lowExtDate)
print(highExt, lowExt)

eachfive=np.array_split(double[1], 10)
def bell(x):
    return np.log(x)
    #return np.linspace(10,10,300)/(np.power(np.linspace(math.e, math.e, 300),x)+np.power(np.linspace(math.e, math.e, 300),-10*x))

figure, axis = plt.subplots(1, 3)
axis[0].plot(double[0], bell(double[1]))
axis[1].hist([bell(eachfive[0]),bell(eachfive[1])], orientation="horizontal", bins=10)
axis[2].boxplot([bell(eachfive[0]),bell(eachfive[1]),bell(eachfive[2]),bell(eachfive[3]),bell(eachfive[4]),bell(eachfive[5]),bell(eachfive[6]),bell(eachfive[7]),bell(eachfive[8]),bell(eachfive[9])])

plt.show()