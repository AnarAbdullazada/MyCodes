import numpy as np
import matplotlib.pyplot as plt

f=open("data.txt", "r")
file=f.read()
list=[]
res=[]
list=file.split("\n")
for elem in list:
    dirt=elem.split("|")
    for e in dirt:
        if e=="":
            dirt.remove(e)
        else:
            dirt[dirt.index(e)]=e.replace(" ", "")
    res.append(dirt)

double=[]
for i in res:
    for k in i:
        if i[0]!=k:
            loop=i.index(k)
            double.append([float(round(int(i[0])+loop*(1/12), 2)), float(k)])
double=np.array(double)
double=np.transpose(double)

mean=np.mean(double[1])
std=np.std(double[1])
std1=std
std2=2*std
std3=3*std
print(mean, std, std1, std2, std3)

print("divisions:")
trf=double[1]<std1
uniques, counts = np.unique(trf, return_counts=True)
print(counts[1], counts[1]/3, "%")
trf1=std1<double[1]
trf2=double[1]<std2
trf = trf1*trf2
uniques, counts = np.unique(trf, return_counts=True)
print(counts[1], counts[1]/3, "%")
trf=std3<double[1]
uniques, counts = np.unique(trf, return_counts=True)
print(counts[1], counts[1]/3, "%")

median=np.median(double[1])
print("median: ", median)

q25 = np.percentile(double[1], [25])
print("first quartile: ", q25[0])
q75 = np.percentile(double[1], [75])
print("third quartile: ", q75[0])
q50=q75-q25
print("interquartile range: ", q50[0])

trf=q25>double[1]
uniques, counts = np.unique(trf, return_counts=True)
q25counts=counts[1]
print("below q25:", q25counts, "percentile:", q25counts/3)
trf=q75<double[1]
uniques, counts = np.unique(trf, return_counts=True)
q75counts=counts[1]
print("above q75:", q75counts, "percentile:", q75counts/3)
q75q25=300-q75counts-q25counts
print("between q25 and q75 (aka iqr): ", q75q25, "percentile:", q75q25/3)

def moving(command):
    avrgStackHistory=[]
    movingStack=[]
    def stackAdd(elem):
        movingStack.append(elem)
        if len(movingStack)>3:
            movingStack.remove(movingStack[0])

    global res
    res=np.array(res)
    for year in res:
        values=np.delete(year, 0)
        if command=="mean":
            Value=np.mean(values.astype(float))
        if command=="std1":
            Value=np.std(values.astype(float))
        if command=="std2":
            Value=np.std(values.astype(float))*2
        if command=="std3":
            Value=np.std(values.astype(float))*3
        if command=="median":
            Value=np.median(values.astype(float))
        if command=="q25":
            Value=np.percentile(values.astype(float), [25])
        if command=="q75":
            Value=np.percentile(values.astype(float), [75])
        if command=="min":
            Value=min(values.astype(float))
        if command=="max":
            Value=max(values.astype(float))
        stackAdd(Value)
        avrgStackHistory.append(np.mean(movingStack))

    for i in range(len(avrgStackHistory)):
        avrgStackHistory[i]=np.linspace(avrgStackHistory[i], avrgStackHistory[i], 12)
    avrgStackHistory=np.reshape(avrgStackHistory, 300)
    return avrgStackHistory

x_axis = double[0]
y_axis = double[1]

plt.plot(x_axis, y_axis)
#plt.plot(x_axis, np.linspace(mean, mean, 300))
#plt.plot(x_axis, np.linspace(std1, std1, 300))
#plt.plot(x_axis, np.linspace(std2, std2, 300))
#plt.plot(x_axis, np.linspace(std3, std3, 300))
#plt.plot(x_axis, np.linspace(q25, q25, 300))
#plt.plot(x_axis, np.linspace(q50, q50, 300))
#plt.plot(x_axis, np.linspace(q75, q75, 300))
#plt.plot(x_axis, np.linspace(median, median, 300))
#plt.plot(x_axis, moving("mean"))
#plt.plot(x_axis, moving("std1"))
#plt.plot(x_axis, moving("std2"))
#plt.plot(x_axis, moving("std3"))
plt.plot(x_axis, moving("median"))
plt.plot(x_axis, moving("q25"))
plt.plot(x_axis, moving("q75"))
plt.plot(x_axis, moving("min"))
plt.plot(x_axis, moving("max"))
plt.title('graph')
plt.xlabel('years')
plt.ylabel('price')
plt.show()