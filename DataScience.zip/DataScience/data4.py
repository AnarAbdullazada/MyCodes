import numpy as np
import matplotlib.pyplot as plt

f=open("data.txt", "r")
file=f.read()
list=[]
res=[]
list=file.split("\n")
for elem in list:
    dirt=elem.split("|")
    for e in dirt:
        if e=="":
            dirt.remove(e)
        else:
            dirt[dirt.index(e)]=e.replace(" ", "")
    res.append(dirt)

double=[]
for i in res:
    for k in i:
        if i[0]!=k:
            loop=i.index(k)
            double.append([float(round(int(i[0])+loop*(1/12), 2)), float(k)])
double=np.array(double)
double=np.transpose(double)

twelveTime=np.array_split(double[0], 3)
eachTwelve=np.array_split(double[1], 3)

ms=[]
bs=[]
for i in range(3):
    m0,b0 = np.polyfit(twelveTime[i], eachTwelve[i], 1)
    ms.append(m0)
    bs.append(b0)
    print(m0, b0)
    plt.plot(twelveTime[i], twelveTime[i]*m0+b0)
print("2022: ",(twelveTime[i]+1)*m0+b0)

ms=np.mean(ms)
bs=np.mean(bs)
m0,b0 = np.polyfit(double[0], double[1], 1)
print("m", m0, ms)
print("b", b0, bs)

plt.plot(double[0], double[0]*m0+b0)
plt.scatter(double[0], double[1])
plt.show()