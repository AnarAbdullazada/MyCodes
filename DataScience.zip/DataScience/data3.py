import numpy as np
import matplotlib.pyplot as plt

f=open("data.txt", "r")
file=f.read()
list=[]
res=[]
list=file.split("\n")
for elem in list:
    dirt=elem.split("|")
    for e in dirt:
        if e=="":
            dirt.remove(e)
        else:
            dirt[dirt.index(e)]=e.replace(" ", "")
    res.append(dirt)

double=[]
for i in res:
    for k in i:
        if i[0]!=k:
            loop=i.index(k)
            double.append([float(round(int(i[0])+loop*(1/12), 2)), float(k)])
double=np.array(double)
double=np.transpose(double)
print(double)

uniques, counts = np.unique(double[1], return_counts=True)
mode=uniques[np.where(counts == max(counts))]
print("mode", mode)

q25 = np.percentile(double[1], [25])
print("first quartile: ", q25[0])
q75 = np.percentile(double[1], [75])
print("third quartile: ", q75[0])

highmark=q75+(q75-q25)*1.5
lowmark=q25-(q75-q25)*1.5

highExtDate=double[0][np.where(double[1]>highmark)]
highExt=double[1][np.where(double[1]>highmark)]
lowExtDate=double[0][np.where(double[1]<lowmark)]
lowExt=double[1][np.where(double[1]<lowmark)]
print(highExtDate, lowExtDate)
print(highExt, lowExt)

figure, axis = plt.subplots(1, 2)
axis[0].boxplot(double[1])
axis[1].hist(double[1], orientation="horizontal")
plt.show()