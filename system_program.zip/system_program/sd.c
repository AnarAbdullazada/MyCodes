#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// a*x^2 + b*x + c = 0
// returns the number of solutions (at most 2).
// solutions are stored in the placeholder *r1 and *r2
int f(int a, int b, int c, float *r1, float *r2)
{
  if (a==0)
    {*r1=(-c/(float)b);
      return 1;
    }
  else
    {
      int delta = b*b-4*a*c;
      if (delta<0)
	{return 0;}
      if (delta==0)
	{*r1=-b/(2*a); return 1;}

      *r1=(-b+sqrt(delta))/(2*a);
      *r2=(-b-sqrt(delta))/(2*a);
      return 2;
    }
}

int main(int argc, char *argv[])
{
  int a,b,c,nb_solutions;
  float f1,f2;

  //  printf("argc = %d\n", argc);
  if (argc < 4)
    {
      printf("usage : %s a b c\n", argv[0]);
      exit(2);
    }
  if (argc > 4)
    {
      printf("%s expects *exactly* 3 arguments, extra arguments will be ignored\n",argv[0]);
      printf("usage : %s a b c\n", argv[0]);
    }
  a=atoi(argv[1]);
  b=atoi(argv[2]);
  c=atoi(argv[3]);
  
  printf("a = %d, b = %d, c = %d\n", a,b,c);

  nb_solutions = f(a,b,c,&f1,&f2);
  if(nb_solutions == 0)
    {
      printf("no solutions available\n");
    }
  else if (nb_solutions ==1)
    {
      printf("one solution : %f\n", f1);
    }
  else
    {
      printf("two solutions : %f and %f\n", f1,f2);
    }
  
  return 0;
}
