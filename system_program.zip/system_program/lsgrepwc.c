#include<stdio.h>
#include <unistd.h>
// ls -all | grep argv[1] | wc -l


int main(int argc, char *argv[])
{
  int pid, pid2;
  int ls2grep[2];
  int grep2wc[2];
  pipe(ls2grep);
  pipe(grep2wc);
  pid=fork();
  
  if (pid==0)
    {
      // child1 - ls -all
      close(grep2wc[0]);
      close(grep2wc[1]);
      close(ls2grep[0]);
      dup2(ls2grep[1],1); 

      execlp("/bin/ls", "ls", "-all", NULL);
    }
  else
    {
      pid2=fork();
	if (pid2==0)
	  {
	    // child2 - grep argv[1]
	    close(grep2wc[0]);
	    close(ls2grep[1]);
	    dup2(ls2grep[0],0);
	    dup2(grep2wc[1],1);
	    execlp("/usr/bin/grep", "grep", argv[1], NULL);
	  }
	else
	  {
	    // parent - wc -l
	    close(grep2wc[1]);
	    close(ls2grep[0]);
	    close(ls2grep[1]);
	    dup2(grep2wc[0],0);
	    execlp("/usr/bin/wc", "wc", "-l", NULL);
	    
	  }

      
    }

  return 0;
}
