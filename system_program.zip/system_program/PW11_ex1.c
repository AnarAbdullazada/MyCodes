#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>


#define  FICHIER  "toto"

int compteur;

void activer_signaux(void);
void ecrire_valeur(int signo);
void terminer(int signo);

int main(void)
{
    activer_signaux();

    compteur = 0;
    printf("compteur = %d \n",compteur);
    for(;;){
        /*
        * en toute rigueur, si on voulait faire quelque chose de
        * complique ici, il faudrait masquer les signaux SIGINT et
        * SIGTERM ici, puis les demasquer apres la section critique,
        * le tout avec la primitive sigprocmask().
        * Dans notre cas, cela n'est pas necessaire.
        */
        compteur++;
    }
}


void activer_signaux(void){
    struct sigaction action;
    
    action.sa_flags = 0;
    
    action.sa_handler = ecrire_valeur;
    sigemptyset(&action.sa_mask);
    /*
    * SIGINT sera implicitement masque lorsqu'on rentrera
    * dans ecrire_valeur().
    * Mais il faut masquer SIGTERM pour ne pas interrompre
    * ecrire_valeur().
    */
    sigaddset(&action.sa_mask, SIGTERM);  /* masquer SIGTERM */
    if(sigaction(SIGINT, &action, NULL) == -1){
        perror("sigaction");
        exit(1);
    }
    
    action.sa_handler = terminer;
    sigemptyset(&action.sa_mask);
    sigaddset(&action.sa_mask, SIGINT);  /* masquer SIGINT */
    if(sigaction(SIGTERM, &action, NULL) == -1){
        perror("sigaction");
        exit(1);
    }
    printf("%d : Signal handlers are ready\n", getpid());
}

void ecrire_valeur( int signo)
{
    FILE *fp;
    char *date_en_clair;
    time_t date_en_secondes;
    
    date_en_secondes = time((time_t *) 0);
    date_en_clair = ctime(&date_en_secondes);
    printf("%s\n",date_en_clair);
    date_en_clair [24] = '\0';  
    
    fp = fopen(FICHIER, "a");
    if(fp == NULL){
        perror("fopen");
        exit(1);
    }
    
    fprintf(fp, "%s %d\n", date_en_clair, compteur);
    if(fclose(fp) == -1){
        perror("fclose");
        exit(1);
    }
}

void terminer( int signo)
{
    FILE *fp;
    
    fp = fopen(FICHIER, "a");
    if(fp == NULL){
        perror("fopen");
        exit(1);
    }
    
    fprintf(fp, "fin\n");
    
    if(fclose(fp) == -1){
        perror("fclose");
        exit(1);
    }
    exit(0);
}

