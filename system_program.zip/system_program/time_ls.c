#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>

int main(int argc, char *argv[])
{
  int pid;
  struct timeval tv1, tv2;

  if (argc!=2)
    { fprintf(stderr, "usage: %s <directory>\n", argv[0]);
      exit(1);
  }
  gettimeofday(&tv1, NULL);
  printf("starting at : %ld,%06d sec\n", tv1.tv_sec, tv1.tv_usec);

  pid=fork();

  if (pid==0)
    {
      // child
      sleep(3);
      execlp("ls", "ls", "-all", argv[1],NULL);
    }
  wait(NULL);
  gettimeofday(&tv2, NULL);
  printf("ended at : %ld,%06d sec \n", tv2.tv_sec, tv2.tv_usec);
  if(tv2.tv_sec==tv1.tv_sec)
    {
      printf("diff = %d micro-sec\n", tv2.tv_usec-tv1.tv_usec);
    }
  else
    {
  printf("diff (approximately) = %ld sec\n", tv2.tv_sec-tv1.tv_sec);
    }
  return 0;
}
