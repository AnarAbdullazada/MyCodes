#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct MYFILE{
    int filemode;
    int filesize;
    char filename[100];
    char fileowner[100];
};

struct MYFILE my_open(char filename[100], char mode){
    FILE *result;
    if(mode=='r'){
        result = open(filename, O_RDONLY);
    }
    if(mode=='w'){
        result = open(filename, O_WRONLY);
    }
    return(my_open(filename, mode));
}
void main(){

    struct MYFILE* file;
    file->filemode=700;
    file->filesize=2000;
    strcpy(file->filename,  "foo.txt");
    strcpy(file->fileowner, "root");
}