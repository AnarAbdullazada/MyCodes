#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sysexits.h>

int main(int argc, char** argv) {
  if (argc != 4) {
    fprintf(stderr, "Usage: %s input1 input2 output\n", argv[0]);
    return EX_USAGE;
  }

  const char* in1 = argv[1];
  const char* in2 = argv[2];
  const char* out = argv[3];
  
  int fd_in1 = open(in1, O_RDONLY);
  int fd_in2 = open(in2, O_RDONLY);
  int fd_out = open(out, O_WRONLY | O_CREAT | O_TRUNC, 0666);

  if (fd_in1 == -1) {
    fprintf(stderr, "%s could not be opened\n", in1);
    return EX_NOINPUT;
  }

  if (fd_in2 == -1) {
    fprintf(stderr, "%s could not be opened\n", in2);
    return EX_NOINPUT;
  }
  
  if (fd_out == -1) {
    fprintf(stderr, "%s could not be opened\n", out);
    return EX_NOINPUT;
  }
  
  char buffer[2] = { '\0' };
  size_t size1 = 0;
  size_t size2 = 0;
  while (((size1 = read(fd_in1, buffer, 1)) == 1) && ((size2 = read(fd_in2, buffer+1, 1)) == 1))
    {
    write(fd_out, &buffer[0], 1);
    write(fd_out, &buffer[1], 1);
    }

  // Write the remaining byte
  if ((size1!=0) &&(size2==0)) {
	write(fd_out, &buffer[0], 1);
  }

  close(fd_in1);
  close(fd_in2);
  close(fd_out);
  
  return 0;
}
