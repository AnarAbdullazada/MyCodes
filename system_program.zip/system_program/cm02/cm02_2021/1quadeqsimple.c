/*
Calculate the quadratic equation with the help of ordinary functions. 

The prototype for function: float solve(float a, float b, float c);

You can create an additional function for calculating discriminant:float discriminant(float, float,float);

See what is the disadvantage of using ordinary function in this problem.
*/
#include <stdio.h>
#include <math.h>

float solve(float a, float b, float c);
float discriminant(float, float,float);

int main()
{
    float a,b,c;
    puts("enter a b c");
    scanf("%f %f %f", &a, &b, &c);
    float root;
    root = solve(a,b,c);
    printf("Root = %f\n", root);
    return 0;
}

float discriminant(float a, float b,float c){
    return pow(b,2)-4*a*c;
}


float solve(float a, float b, float c)
{
    float root;
    // int nb_sol;
    float d= discriminant(a,b,c);
    if(d<0){
        // nb_sol=0;
        puts("no roots");
    }else if(d==0){
        // nb_sol=1;
        root = -b/(2*a);
    }else{
        // nb_sol=2;
        root = (-b - sqrt(d))/(2*a);
    }
    return root;
    
}
















