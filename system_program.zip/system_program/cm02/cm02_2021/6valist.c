/*
In C, you can pass variable arguments to function everytime you call it. This can be achieved by using macros va_start(), va_arg(), va_end(). See below example to have a better understanding.
*/

#include <stdio.h>
#include <stdarg.h>

double average(int num, ...)
{
    va_list list;
    double sum = 0.0;
    int i;
    /*initialize valist for num number of arguments to be used with va_arg and va_end */
    va_start(list, num);
    /*access all the arguments assigned to valist */
    for (i = 0; i < num; i++)
    {
        sum += va_arg(list, double);
    }
    /*clean memory reserved for valist */
    va_end(list);

    return sum / num;
}

int main()
{
    printf("Average of 2, 3, 4, 5 = %f\n", average(4, 2.0, 3.0, 4.0, 5.0));
    printf("Average of 5, 10, 15 is %f\n", average(3, 5.0, 10.0, 15.0));
}
