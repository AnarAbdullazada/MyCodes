//function pointers in c
// //
//     & is the address-of operator, and can be read simply as "address of"
//     * is the dereference operator, and can be read as "value pointed to by"

#include <stdio.h>

int sum(int num1, int num2) //256 -> 260
{
    return num1 + num2;
}
int mult(int num1, int num2)
{
    return num1 * num2;
}
int division(int num1, int num2)
{
    return num1 / num2;
}

int main()
{
    int (*f2p)(int, int) = &sum; //declare a pointer to function 2.Pass the Address of the Desired function


    //calling function using function pointer
    int op1 = f2p(10, 13);

    //calling function in normal way using function name
    int op2 = sum(10, 13);

    f2p = mult;
    int op3 = mult(10, 13);
    f2p = division; //assign address of function to pointer
    int op4 = (*f2p)(20, 2);
    printf("Output1: Call using function pointer: %d\n", op1);
    printf("Output2: Call using function name: %d\n", op2);
    printf("Output3: Call using function name: %d\n", op3);
    printf("Output4: using function pointer: %d\n", op4);

    return 0;
}