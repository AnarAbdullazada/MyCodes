#include <math.h>
#include <stdio.h>
#include "quadeq.h"


int solve(float a, float b, float c, float *s1, float *s2)
{
    int d = discriminat(a, b, c);
    int nb_sol;
    if (d < 0)
    {
        nb_sol = 0;
        puts("No roots");
    }
    else if (d == 0)
    {
        nb_sol = 1;
        *s1 = -b / (2 * a);
    }
    else if (d > 0)
    {
        nb_sol = 2;
        *s1 = (-b + sqrt(d)) / (2 * a);
        *s2 = (-b - sqrt(d)) / (2 * a);
    }

    return nb_sol;
}