//header where prototype of functions reside
int solve(float a, float b, float c, float *s1, float *s2);
int discriminat(float a, float b, float c);

