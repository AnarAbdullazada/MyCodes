#include <stdio.h>
#include "quadeq.h"

int main()
{
    float a, b, c;
    puts("Enter a, b, c consequently");
    scanf("%f %f %f", &a, &b, &c);
    printf("You entered a=%f, b=%f, c=%f\n", a, b, c);
    float root1, root2;
    int result = solve(a,b,c,&root1, &root2);
    if(result == 0){
        puts("No solution");
    }else if(result == 1){
        printf("only one root -> %f\n", root1);
    }else if(result == 2){
        printf("Root1=%f, Root2 = %f\n", root1, root2);
    }
    puts("wuhu");

    return 0;
}


