#include<math.h>
#include<stdio.h>
#include"quadeq.h"

int discriminat(float a, float b, float c)
{
    return pow(b, 2) - 4 * a * c;
}
