/*
Use pointers to calculate quadratic equation.

The prototype for function is: int solve(float a, float b, float c, float *s1, float *s2);

You can re-use discriminant function from previous examples.

What is the benefit of using pointers in this problem?
*/

#include <stdio.h>
#include <math.h>

int solve(float a, float b, float c, float *s1, float *s2);
float discriminant(float, float, float);

int main()
{
    float a, b, c;
    puts("Enter a b c");
    scanf("%f %f %f", &a, &b, &c);
    float root1, root2;
    int n;
    n = solve(a, b, c, &root1, &root2);
    if (n == 0)
    {
        puts("No solution");
    }
    else if (n == 1)
    {
        printf("Root1 = %f\n", root1);
    }
    else if (n == 2)
    {
        printf("Root1 = %f\nRoot2 = %f\n", root1, root2);
    }
    return 0;
}
int solve(float a, float b, float c, float *s1, float *s2)
{
    float d = discriminant(a, b, c);
    int nb_sol;
    if (d < 0)
    {
        nb_sol = 0;
    }
    else if (d == 0)
    {
        nb_sol = 1;
        *s1 = -b / (2 * a);
    }
    else
    {
        nb_sol = 2;
        *s1 = (-b - sqrt(d)) / (2 * a);
        *s2 = (-b + sqrt(d)) / (2 * a);
    }
    return nb_sol;
}
float discriminant(float a, float b, float c)
{
    return pow(b, 2) - 4 * a * c;
}
*/
