/*
Use struct to calculate the quadratic equation. 

typedef struct solutions
{
    int nb_solutions;
    float s1;
    float s2;
} solution;
What can we achieve by using struct in this problem?
*/

#include <stdio.h>
#include <math.h>

typedef struct solutions
{
    int nb_solutions;
    float s1;
    float s2;
} solution;

solution solve(float, float, float);

float discriminant(float, float, float);

int main()
{
    float a, b, c;
    puts("Enter a b c");
    scanf("%f %f %f", &a, &b, &c);
    solution result;
    result = solve(a,b,c);
    if( result.nb_solutions==0){
        puts("No root");
    }else if(result.nb_solutions==1){
        printf("One root only; root = %f\n", result.s1);
    }else{
        printf("Root1 = %f\nRoot2 = %f\n", result.s1, result.s2);
    }
    return 0;
}

float discriminant(float a, float b, float c)
{
    return pow(b, 2) - 4 * a * c;
}

solution solve(float a, float b, float c)
{
    solution s;
    float d = discriminant(a, b, c);
    if (d < 0)
    {
        s.nb_solutions = 0;
    }
    else if (d == 0)
    {
        s.nb_solutions = 1;
        s.s1 = -b / (2 * a);
    }
    else
    {
        s.nb_solutions = 2;
        s.s1 = (-b - sqrt(d)) / (2 * a);
        s.s2 = (-b + sqrt(d)) / (2 * a);
    }
    return s;
}
*/
