#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sysexits.h>

int main(int argc, char** argv) {
  if (argc != 4) {
    fprintf(stderr, "Usage: %s input output1 output2\n", argv[0]);
    return EX_USAGE;
  }

  const char* in = argv[1];
  const char* out1 = argv[2];
  const char* out2 = argv[3];
  
  int fd_in = open(in, O_RDONLY);
  int fd_out1 = open(out1, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  int fd_out2 = open(out2, O_WRONLY | O_CREAT | O_TRUNC, 0666);

  if (fd_in == -1) {
    fprintf(stderr, "%s could not be opened\n", in);
    return EX_NOINPUT;
  }

  if (fd_out1 == -1) {
    fprintf(stderr, "%s could not be opened\n", out1);
    return EX_NOINPUT;
  }

  if (fd_out2 == -1) {
    fprintf(stderr, "%s could not be opened\n", out2);
    return EX_NOINPUT;
  }
  
  char buffer[2] = { '\0' };
  size_t size = 0;
  while ((size = read(fd_in, buffer, 2)) == 2) {
    write(fd_out1, &buffer[0], 1);
    write(fd_out2, &buffer[1], 1);
  }

  // Write the remaining byte
  if (size > 0) {
    write(fd_out1, &buffer[0], 1);
  }

  close(fd_in);
  close(fd_out1);
  close(fd_out2);
  
  return 0;
}
