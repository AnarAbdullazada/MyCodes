#include <stdio.h>
#include <string.h>
#include  <sys/stat.h>
int main () {
    FILE *fp;
    char str[100];
    char input[100];
    char empty[100]="hhh";
    fp = fopen("toto.txt" , "w");
    fopen("toto.txt", "r");
    fopen("toto.txt", "w");
    fputs("hello world", fp);
    fclose(fp);

    fopen("toto.txt", "r");
    fgets(str , 20, fp);
    int filelen = strlen(str);
    fclose(fp);

    fopen("toto.txt", "r");
    for(int i = 0; i < filelen; i++){
        fgets(str , 2, fp);
        puts(str);
    }
    fclose(fp);

    fopen("toto.txt", "a");
    char buf[5]="";
    while(strcmp(buf, "END")){
        printf("Enter a char: ");
        gets(buf);
        if(strlen(buf)==1){
            fputs(buf, fp);
        }
        else{
        printf("Only one char: \n");
        }
    }
    fclose(fp);

    return(0);
}