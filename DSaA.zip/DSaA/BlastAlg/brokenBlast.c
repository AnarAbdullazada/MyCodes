#include <stdio.h>
#define MAXLENGTH 35
/* Basic BLAST (basic local alignment search tool) algorithm
Author: Ali Gurbanov, UNISTRA id : 22022750 */

int myStrlen(char sMyString[]);
void blastAlg(char match[]);

int main(int argc, char* argv[]){
  char match[]="011100000101101011110000011";
  blastAlg(match);
}

//prints best cumulative score and position as output
void blastAlg(char match[]){
  int nBestScore = 0, nCurrentScore=0, nBestPosition = 0, nCurrentPosition;
  for (int nCurrentPosition = 0; nCurrentPosition<myStrlen(match); nCurrentPosition++){
    if (match[nCurrentPosition] == '1'){
      nCurrentScore += 1;
    }
    else if (match[nCurrentPosition] == '0' && nCurrentScore > 0){
      nCurrentScore -= 1;
    }
    if (nCurrentScore>nBestScore){
      nBestScore=nCurrentScore;
    }
  }
  printf("%d\n",nBestScore);
}

// return length of the string, for not using entire string.h  
int myStrlen(char sMyString[]){
  int nLength = 0;
  while(sMyString[nLength++]);
  return nLength-1;}