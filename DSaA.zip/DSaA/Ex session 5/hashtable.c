#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Droplet{
  int *value;
  struct Droplet* next;
};

struct Droplet** hasher(int inputs[], int size) {
  struct Droplet** temp = malloc(50 * sizeof(struct Droplet*));
  for (int i = 0; i < 50; i++) {
    temp[i] = malloc(sizeof(struct Droplet)); // allocate memory for each element
    temp[i]->value = NULL;
    temp[i]->next  = NULL;
  }
  for (int i = 0; i < size; i++) {
    struct Droplet* current = temp[inputs[i] % 50];
    while (1) {
      if (current->value == NULL) {
        current->value = malloc(sizeof(int)); // allocate memory for value
        *(current->value) = inputs[i];
        printf("%p when set %d\n", current->value, *(current->value));
        break;
      } else {
        if (current->next == NULL) {
          current->next = malloc(sizeof(struct Droplet));
          current->next->value = NULL;
          current->next->next = NULL;
        }
        current = current->next;
      }
    }
  }
  return temp;
}

void printHTable(struct Droplet* inputs[50], int size) {
  for(int i=0; i<50; i++){
    struct Droplet* temp = inputs[i];
    if((temp->value)!=NULL){
      printf("%d, ", *(temp->value));//why doesnt work when dereferencing with??? *(temp->value)
    }
  }
}

int main(){
  int hashies[50];
  int tempi; int i;
  for (i=0; i<50; i++){
    if(tempi==60){break;}
    scanf("%d", &tempi);
    hashies[i] = tempi;
    printf("%d\n", hashies[i]);
  }

  struct Droplet* hashed[50];
  memcpy(hashed,  hasher(hashies, i), 50*sizeof(struct Droplet));

  printHTable(hashed, i);
  
  return 0;
}
