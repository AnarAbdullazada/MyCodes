def dominates(a, b):
  """
  Returns True if 'a' dominates 'b', False otherwise.
  """
  return all(ai >= bi for ai, bi in zip(a, b)) and any(ai > bi for ai, bi in zip(a, b))


def pareto_front(points):
  """
  Returns the Pareto front of the given points.
  """
  # Initialize an empty list of solutions
  solutions = []
      
  # Loop over each point in the input list
  for p in points:
    # Check if the point is dominated by any of the solutions
    dominated = False
    to_remove = []
    for i, s in enumerate(solutions):
      if dominates(s, p):
        dominated = True
        break
      elif dominates(p, s):
        to_remove.append(i)
    
    # If the point is not dominated, add it to the solution list
    if not dominated:
      solutions.append(p)
      # Remove any dominated solutions from the solution list
      for i in reversed(to_remove):
        del solutions[i]
      
  # Return the solution list
  return solutions

points = [
  (1, 2),
  (3, 1),
  (2, 3),
  (4, 2),
  (3, 3),
  (2, 4),
  (1, 4),
  (4, 3),
  (3, 4),
  (4, 4)
]

# Compute the Pareto front
front = pareto_front(points)

# Print the results
print("Pareto front:")
for p in front:
  print(p)
