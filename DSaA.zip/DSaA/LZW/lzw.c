#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Node{
  int  iCode;
  char cChar;
  int  iUses;
  struct Node* next;
};

int printLL(struct Node* begin){
  struct Node* temp=begin; int i=0;
  for(i=0; temp!=NULL; i++){
    if(temp->cChar != '\0'){
      printf("%d : %d%c   %d\n", i, temp->iCode, temp->cChar, temp->iUses);
    }
    temp=temp->next;
  }
  printf("length: %d\n", i);
  return i;
}

struct Node* createLL(struct Node* begin, char initTable[6], int size){
  struct Node* temp=begin; struct Node* mem;
  for(int i=0; i<size; i++){
    temp->iCode = -1;
    temp->cChar = initTable[i];
    temp->iUses = 1;
    printf("%c\n", temp->cChar);
    temp->next  = malloc(sizeof(struct Node));
    mem = temp;
    temp=temp->next;
  }
  temp->next=NULL;
  return mem;
}

int SearchLL(struct Node* begin, char cChar, int iCode){
  struct Node* temp = begin; int index = 0;
  while(temp != NULL){
    if((temp->cChar == cChar)&&(temp->iCode == iCode)){
      return index;
    }
    temp = temp->next;
    index++;
  } return -1; // not found
}

struct Node* addToLL(struct Node* lastNode, char cChar, int iCode){
  lastNode->next = malloc(sizeof(struct Node));
  lastNode->next->iCode = iCode;
  lastNode->next->cChar = cChar;
  lastNode->next->iUses = 0;
  lastNode->next->next = NULL;
  lastNode=lastNode->next;
  return lastNode;
}

void LZW_Alg(struct Node* begin, struct Node* lastNode, char Sentence[35], int size){
  int lastICode=-1;
  for(int i=0; i<size; i++){
    int index = SearchLL(begin, Sentence[i], lastICode);
    printf("foundOrNot? %d%c: %d  \n", lastICode, Sentence[i], index);
    if(index == -1){
      lastNode = addToLL(lastNode, Sentence[i], lastICode);
      printf("add: %d%c \n", lastICode, Sentence[i]);
      lastICode=-1;
      i--;
    }
    else{
      lastICode=index;
      lastNode->iUses=lastNode->iUses+1;
      printf("iUses %d\n", lastNode->iUses);
    }
  }
}

struct Branch {
  struct Node*   self;
  struct Branch* parent;
  int sumOfiUses;
  struct Branch* next;
};

struct returnStruct{
  struct Branch* beginLeaf;
  struct Branch* endLeaf;
};
struct returnStruct* LLtoTreeNodeLL(struct Node* begin, int length){
  struct Node* temp = begin;
  struct Branch* leaf = (struct Branch*)malloc(sizeof(struct Branch));
  struct Branch* tleaf = leaf;
  for(int i=0; temp != NULL; i++){
    tleaf->self = temp; tleaf->parent = NULL;
    tleaf->sumOfiUses = temp->iUses;
    if(temp->next == NULL){ tleaf->next=NULL; }
    tleaf->next = (struct Branch*)malloc(sizeof(struct Branch));
    tleaf = tleaf->next;
    temp  = temp ->next;
  }
  struct returnStruct* myReturnStruct = (struct returnStruct*)malloc(sizeof(struct returnStruct));;
  myReturnStruct->beginLeaf= leaf;
  myReturnStruct->endLeaf  =tleaf;
  return myReturnStruct;
}
struct Branch* FindInLL(struct Branch* leaf, int index){
  struct Branch* temp = leaf;
  for(int i=0; temp != NULL; i++){
    if(i==index){ return temp;  }
    else{ temp = temp->next; }
  } return NULL; // not found
}
struct returnStruct* joinLowestUseCouple(int length, struct returnStruct* returnLeafs) {
  int minimum=1000000; int iNow=0; int kNow=0; int sumOfUses=0;
  struct Branch* minLeftLeaf; struct Branch* minRightLeaf;
  struct Branch* beforeMinLeftLeaf; struct Branch* afterMinLeftLeaf ;
  struct Branch* beforeMinRightLeaf; struct Branch* afterMinRightLeaf;
  struct Branch* leftLeaf; struct Branch* rightLeaf;
  //find the couple with smallest sum of uses.
  printf("find the couple with smallest sum of uses.\n");
  struct Branch* newLeaf = (struct Branch*)malloc(sizeof(struct Branch));
  int k; int i;
  for(k=0; k<length-1; k++){
    for(i=(k+1); i<length; i++){
      leftLeaf  = FindInLL(returnLeafs->beginLeaf, k);
      rightLeaf = FindInLL(returnLeafs->beginLeaf, i);

      sumOfUses = leftLeaf->sumOfiUses + rightLeaf->sumOfiUses;
      if(sumOfUses<minimum){
        minimum = sumOfUses;
        minLeftLeaf  = leftLeaf ;
        minRightLeaf = rightLeaf;
        iNow = i; kNow = k;
      }
    }
  }
  printf("Minimum %d, @i=%d; k=%d\n", minimum, iNow, kNow);
  printf("found the couple with smallest sum of uses.\n");
  //found the couple with smallest sum of uses.

  //remove couple from "TreeNodeLL".
  printf("remove couple from TreeNodeLL.\n");
  printf("length: %d; iNow: %d; kNow: %d\n", length, iNow, kNow);
  beforeMinLeftLeaf = FindInLL(returnLeafs->beginLeaf, kNow-1);
  afterMinLeftLeaf  = FindInLL(returnLeafs->beginLeaf, kNow+1);
  if((0<kNow)&&(kNow<length-1)){
    beforeMinLeftLeaf->next = afterMinLeftLeaf;
  }
  else if(0==kNow){ beforeMinLeftLeaf=NULL; returnLeafs->beginLeaf=returnLeafs->beginLeaf->next; }
  else if(kNow==length-1){ afterMinLeftLeaf =NULL; afterMinLeftLeaf->next=NULL; }
  iNow--;
  beforeMinRightLeaf = FindInLL(returnLeafs->beginLeaf, iNow-1);
  afterMinRightLeaf  = FindInLL(returnLeafs->beginLeaf, iNow+1);
  if((0<iNow)&&(iNow<length-1)){
    beforeMinRightLeaf->next = afterMinRightLeaf;
  }
  else if(0==iNow){ beforeMinRightLeaf=NULL; returnLeafs->beginLeaf=returnLeafs->beginLeaf->next; }
  else if(iNow==length-1){ afterMinRightLeaf=NULL; beforeMinRightLeaf->next=NULL; }
  printf("removed couple from TreeNodeLL.\n");
  //removed couple from "TreeNodeLL".

  //give them common parent.
  newLeaf->self = NULL; newLeaf->parent = NULL;
  newLeaf->sumOfiUses = minimum;
  minLeftLeaf->parent = newLeaf; minRightLeaf->parent = newLeaf;
  //gave them common parent.

  //put parent into "TreeNodeLL".
  returnLeafs->endLeaf->next = newLeaf;
  newLeaf->next = NULL;
  //done putting parent into "TreeNodeLL".
  return returnLeafs;
}

/*
void printBinTree(struct Branch* root, int level) {
  if (root == NULL) {
    return;
  }
  printBinTree(root->next, level + 1);
  printf("%*s%d\n", level * 4, "", root->sumOfiUses);
  printBinTree(root->parent, level + 1);
}*/

void printfBits(int length, int ppBitChunkArray[length]){
  for(int i=0; i<length; i++){
    int chunk = ppBitChunkArray[i]; printf("%u; ", chunk);
  }
}
int toBitCode(struct Node* begin, int length){
  struct returnStruct* returnLeafs = LLtoTreeNodeLL(begin, length);
  for(int i=0; i<length; i++){
    printf("check1\n");
    returnLeafs = joinLowestUseCouple(length-i, returnLeafs);
    printf("check2\n");
  }
  
  //take joined ones from begin LL.
  //printBinTree(begin, 10);
  struct Node* temp = begin;
  int ppBitChunkArray[length];
  //for(int i=0; i<length; i++){
  //  temp=temp->next;
  //  printfBits(length, ppBitChunkArray);
  //}
}

void main() {
  struct Node* begin = malloc(sizeof(struct Node));
  char initTable[] ="edi_t";

  struct Node* lastNode = createLL(begin, initTable, 5);
  printf("created...\n");
  printLL(begin);
  char Sentence[] = "eddie_editted_it_did_eddie_edit_it";
  addToLL(lastNode, 'L', -1);
  LZW_Alg(begin, lastNode, Sentence, sizeof(Sentence)/sizeof(Sentence[0]));
  int length = printLL(begin);
  
  toBitCode(begin, 26);
  printf("\nProgram Finished");
}
