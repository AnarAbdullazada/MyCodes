#include <stdio.h>
#include <stdlib.h>

struct Branch {
  int value;
  struct Branch* left;
  struct Branch* right;
};

struct Branch* createBranch(int value) {
  struct Branch* Branch = (struct Branch*)malloc(sizeof(struct Branch));
  Branch->value = value;
  Branch->left = NULL;
  Branch->right = NULL;
  return Branch;
}

void printTree(struct Branch* root, int level) {
  if (root == NULL) {
    return;
  }
  printTree(root->right, level + 1);
  for (int i = 0; i < level; i++) {
    printf("  ");
  }
  printf("%d\n", root->value);
  printTree(root->left, level + 1);
}

int main() {
  struct Branch* root = createBranch(10);
  root->left = createBranch(5);
  root->right = createBranch(20);
  root->left->left = createBranch(3);
  root->left->right = createBranch(8);
  root->right->left = createBranch(15);
  root->right->right = createBranch(25);
  root->left->left->left = createBranch(2);
  root->left->left->right = createBranch(4);
  root->left->right->left = createBranch(7);
  root->left->right->right = createBranch(9);
  root->right->left->left = createBranch(14);
  root->right->left->right = createBranch(18);
  root->right->right->left = createBranch(24);
  root->right->right->right = createBranch(30);

  printTree(root, 0);
  return 0;
}
