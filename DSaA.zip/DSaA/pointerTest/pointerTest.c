#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//It works :)

void main() {
  void *pAnyInt = malloc(sizeof(void));
  printf("size of unsigned int: %d\n", sizeof(void));
  for(int i=0; i<2; i++){
    *(char*)pAnyInt = '\0'; //same as (char)0;
    printf("myAdress: %p; myValue: %p\n", pAnyInt, *(int*)pAnyInt);
    pAnyInt=(pAnyInt+1);
  }
}
