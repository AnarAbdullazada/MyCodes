#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct AllVar{
  char VarNames[1000][50];//We should use hashtable instead,
  int  AllVCounter;       //it would be faster.
  void *pAnyType[1000];
};
struct AllVar CVars = {.AllVCounter=0};

void* getvar(char VarName[50]){
  int i;
  for(i=0; i<1000; i++){
    if(strcmp(CVars.VarNames[i], VarName)){ break; }
  }
  return CVars.pAnyType[i];
}

void setvar(char VarName[50], void *pAnyType){
  int foundIt=0; int i;
  for(i=0; i<1000; i++){
    if(strcmp(CVars.VarNames[i], VarName)==0){foundIt=1; break; }
  }
  if(foundIt){
    char mem = getvar(VarName);
    printf("%s \n", mem);
    
    CVars.pAnyType[i] = pAnyType;
    printf("%d \n", i);
    printf("%d \n", pAnyType);
    printf("%s \n", CVars.pAnyType[i]);
  }

  else{
    strcpy(CVars.VarNames[CVars.AllVCounter], VarName);
    CVars.AllVCounter++;
    CVars.pAnyType[CVars.AllVCounter] = pAnyType;
  }
}

//typeless c variables.
void main() {
  CVars.AllVCounter=0;
  void* x;
  setvar("myVar", 'h');
  x=getvar("myVar");
  setvar("myVar", 15);

  printf("value: %c\n", x);
}
