//sym [-ahsv] [-seed number] [-o name] [-n number] [-size number]
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define BMP_HEADER_SIZE 14
#define BMP_INFOHEADER_SIZE 40

int readBMP(
  const char *out_filename, int seed, int height, int width, int bytes_per_pixel, int padding,
  unsigned char pixel_data[height][width * bytes_per_pixel + padding],
  unsigned char header[BMP_HEADER_SIZE], unsigned char info_header[BMP_INFOHEADER_SIZE], int outFType
  ){
  int limitWidth;
  if(outFType==0){ limitWidth=width-2; }
  else if(outFType==1){ limitWidth=width-2; }
  else if(outFType==2){ limitWidth=width/2-1; }
  else if(outFType==3){ printf("program for vertical generation not complete ending."); return -1; }
  else if(outFType==4){ limitWidth=width*3; }
  int modMem[2*limitWidth+1][3]; int memCord[2*limitWidth+1][2]; int modMemDim1=0;
  int x=0; int y; srand(seed); int random; int tobeAdded;
  //Set strating position.
  y=(rand()%(height/2)-(height/4))+height/2;//unstable!
  for(int i=0; i<limitWidth; i++){
    random = rand();
    if((outFType == 1)||(outFType == 4)){ tobeAdded = 0; }
    else{ tobeAdded = random % 3 - 1; } //Generate random integer between -1 and 1.
    x=x+1; y=y+tobeAdded; 
    if(y>height){ y=height; } if(y<0){ y=0; }//Protections.
    //Modify the pixel at position (x, y)
    modMem[modMemDim1][0] = pixel_data[y][x * bytes_per_pixel + 0];
    modMem[modMemDim1][1] = pixel_data[y][x * bytes_per_pixel + 1];
    modMem[modMemDim1][2] = pixel_data[y][x * bytes_per_pixel + 2];
    memCord[modMemDim1][0]=y; memCord[modMemDim1][1]=x;
    modMemDim1++;
    pixel_data[y][x * bytes_per_pixel + 0] = 0  ; //Blue channel
    pixel_data[y][x * bytes_per_pixel + 1] = 0  ; //Green channel
    pixel_data[y][x * bytes_per_pixel + 2] = 255; //Red channel
  }
  if(outFType==2){
    int currentModMemDim1 = modMemDim1;
    for(int i=0; i<limitWidth; i++){
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 0] = 0; // blue channel
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 1] = 0; // green channel
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 2] = 255; // red channel
    }
  }
  // open the output file for writing
  FILE *out_fp = fopen(out_filename, "wb");
  if (out_fp == NULL) {
    fprintf(stderr, "Error: could not open file '%s' for writing\n", out_filename);
    fclose(out_fp);
    return -1;
  }
  // write the header and info header to the output file
  fwrite(header, sizeof(unsigned char), BMP_HEADER_SIZE, out_fp);
  fwrite(info_header, sizeof(unsigned char), BMP_INFOHEADER_SIZE, out_fp);
  // write the modified pixel data to the output file

  if(outFType==3){//still doesn't work.
    unsigned char pixel_data_transpose[width * bytes_per_pixel + padding][height];
    for (int i = 0; i < height; ++i){
      for (int j = 0; j < (width * bytes_per_pixel + padding); ++j) {
        pixel_data_transpose[j][i] = pixel_data[i][j];
      }
    }
    fwrite(pixel_data_transpose, sizeof(unsigned char), height * (width * bytes_per_pixel + padding), out_fp);
  }
  else{
    fwrite(pixel_data, sizeof(unsigned char), height * (width * bytes_per_pixel + padding), out_fp);
  }
  fclose(out_fp);
  int i;
  for(i=0; i<limitWidth; i++){
    // modify the pixel at position (x, y)
    pixel_data[memCord[i][0]][memCord[i][1] * bytes_per_pixel + 0] = modMem[i][0]; // blue channel
    pixel_data[memCord[i][0]][memCord[i][1] * bytes_per_pixel + 1] = modMem[i][1]; // green channel
    pixel_data[memCord[i][0]][memCord[i][1] * bytes_per_pixel + 2] = modMem[i][2]; // red channel
    if(outFType==2){
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 0] = modMem[modMemDim1-i][0]; // blue channel
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 1] = modMem[modMemDim1-i][1]; // green channel
      pixel_data[memCord[i][0]][31*3-memCord[i][1] * bytes_per_pixel + 2] = modMem[modMemDim1-i][2]; // red channel
    }
  }
  return random;
}

int main(int argc, char *argv[]) {
  //if(argc!=5){ printf("Usage: sym [-ahsv] [-seed number] [-o name] [-n number] [-size number]"); return -1; }
  char* filename = "./img/example.bmp";
  FILE *fp = fopen(filename, "rb");
  if (fp == NULL) { fprintf(stderr, "Error: could not open file '%s'\n", filename); return 0; }
  // read the header
  unsigned char header[BMP_HEADER_SIZE];
  fread(header, sizeof(unsigned char), BMP_HEADER_SIZE, fp);
  int offset = *(int*)&header[10];
  // read the info header
  unsigned char info_header[BMP_INFOHEADER_SIZE];
  fread(info_header, sizeof(unsigned char), BMP_INFOHEADER_SIZE, fp);
  // read the pixel data
  int width = *(int*)&info_header[4];
  int height = *(int*)&info_header[8];
  int bit_depth = *(int*)&info_header[14];
  int bytes_per_pixel = bit_depth / 8;
  int padding = (4 - (width * bytes_per_pixel) % 4) % 4;
  unsigned char pixel_data[height][width * bytes_per_pixel + padding];
  fread(pixel_data, sizeof(unsigned char), height * (width * bytes_per_pixel + padding), fp);
  fclose(fp);

  //read configuration arguments.
    //read output type
  int outFType=1;
  switch(argv[1][1]){
    case 'a':
      outFType=0; break;
    case 'h':
      outFType=1; break;
    case 's':
      outFType=2; break;
    case 'v':
      outFType=3; break;
    default:
      outFType=4; break;
  }
  printf("output type %d\n", outFType);

    //read seed
  char *seed = argv[2]; int initSeed;
  if(argv[2] == NULL){ initSeed = (int)time(NULL); }
  else{ initSeed = atoi(seed); }
  int nextSeed = initSeed; char outputFiles[20];
  printf("initial seed: %d\n", initSeed);
  //have read configuration arguments.
  int outFileNumber = atoi(argv[4]);
  printf("number of outputs: %d\n", outFileNumber);

  char outname[100];
  strcpy(outname, argv[3]);
  printf("output file name: %s[N].bmp\n", outname);
  for(int i=0; i<outFileNumber; i++){
    sprintf(outputFiles, "./out/%s%d.bmp", outname, i);
    nextSeed = readBMP(
      outputFiles, nextSeed, height, width, bytes_per_pixel, padding,
      pixel_data, header, info_header, outFType
    );
  }
  printf("finished\n");
  return 0;
}
