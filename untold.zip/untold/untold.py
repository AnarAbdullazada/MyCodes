from distutils.log import debug
from flask import Flask, render_template, request
from sqlalchemy import create_engine
#from waitress import serve

app = Flask(__name__)

engine = create_engine("mysql://root@localhost/untold?charset=utf8")
con = engine.connect()

@app.route('/', methods=['POST', 'GET'])
def index():
    command="SELECT * FROM products WHERE 1;"
    res=con.execute(command)
    res=list(res)
    command1="SELECT * FROM producttypes WHERE 1;"
    tyres=con.execute(command1)
    tyres=list(tyres)
    print(tyres)
    return render_template('untoldC.html', res=res, tyres=tyres)
@app.route('/admin', methods=['POST', 'GET'])
def admin():
    if request.method == 'POST':
        if request.form.get('pr'):
            productName=request.form.get('Name')
            productPrice=request.form.get('Price')
            productImage=request.form.get('Image')
            productTypeID=request.form.get('Type')
            command1="INSERT INTO products (productName ,productPrice ,productImage, productTypeID) VALUES('"+productName+"','"+productPrice+"','"+productImage+"','"+productTypeID+"')"
            con.execute(command1)
        if request.form.get('ty'):
            productTypeName=request.form.get('TypeName')
            command2="INSERT INTO producttypes (productTypeName) VALUES('"+productTypeName+"')"
            con.execute(command2)
        if request.form.get('dl'):
            productID=request.form.get('productID')
            command3="DELETE FROM products WHERE productID='"+productID+"'"
            con.execute(command3)
    return render_template("admin.html")
if __name__ == "__main__":
    app.run(host="127.0.0.1", port="5000")
    #serve(app, host="127.0.0.1", port=5000)